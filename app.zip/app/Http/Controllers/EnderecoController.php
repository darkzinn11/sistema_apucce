<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Endereco extends Model
{
    use HasFactory;

    protected $table = 'enderecos';
    public $timestamps = true;

    /**
     * Tabela não possui ID autoincrement (comum nesse cenário).
     * Usaremos operações por atributos (ex.: updateOrCreate).
     */
    protected $primaryKey = null;
    public $incrementing = false;
    protected $keyType = 'string';

    protected $fillable = [
        'cpf_piloto',
        'tipo_endereco',
        'cep',
        'numero',
        'logradouro',
        'complemento',
        'bairro',
        'cidade',
        'uf',
        'pais',
    ];

    protected $casts = [
        // sem casts obrigatórios; adicione se precisar
    ];

    /* ==========================
     |  Relationships
     |==========================*/

    /**
     * Relaciona com Piloto via cpf_piloto (chave não padrão).
     * Observação: não é FK nativa; apenas vínculo lógico.
     */
    public function piloto()
    {
        return $this->belongsTo(Piloto::class, 'cpf_piloto', 'cpf_piloto');
    }

    /* ==========================
     |  Accessors / Mutators
     |==========================*/

    public function setUfAttribute($value): void
    {
        $this->attributes['uf'] = is_string($value) ? strtoupper($value) : $value;
    }

    public function setPaisAttribute($value): void
    {
        $this->attributes['pais'] = ($value === null || $value === '')
            ? 'Brasil'
            : $value;
    }

    public function setTipoEnderecoAttribute($value): void
    {
        $this->attributes['tipo_endereco'] = ($value === null || $value === '')
            ? 'RESIDENCIAL'
            : $value;
    }

    /**
     * Endereço legível para exibição.
     */
    public function getEnderecoCompletoAttribute(): string
    {
        $partes = array_filter([
            $this->logradouro,
            $this->numero,
            $this->bairro,
            $this->cidade ? "{$this->cidade}/{$this->uf}" : null,
            $this->cep ? "CEP {$this->cep}" : null,
            $this->pais,
        ], fn ($v) => !empty($v));

        return implode(', ', $partes);
    }

    /* ==========================
     |  Scopes
     |==========================*/

    public function scopeDoPiloto($query, string $cpf)
    {
        return $query->where('cpf_piloto', $cpf);
    }
}
