<?php

namespace App\Http\Controllers;

use App\Models\Piloto;
use App\Models\Usuario;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class PilotoController extends Controller
{
    /* =========================================================
     * Utils de esquema/consulta
     * =======================================================*/

    protected function tableColumns(): array
    {
        return Schema::hasTable('pilotos') ? Schema::getColumnListing('pilotos') : [];
    }

    protected function findByCpf($cpf): ?Piloto
    {
        foreach (['cpf_piloto', 'cpf', 'cpfPiloto', 'id_piloto'] as $col) {
            if (Schema::hasColumn('pilotos', $col)) {
                $p = Piloto::where($col, $cpf)->first();
                if ($p) return $p;
            }
        }
        return null;
    }

    protected function findByEmail(string $email): ?Piloto
    {
        foreach (['email_piloto','email'] as $c) {
            if (Schema::hasColumn('pilotos', $c)) {
                $p = Piloto::where($c, $email)->first();
                if ($p) return $p;
            }
        }
        if (Schema::hasColumn('pilotos', 'usuario_id')) {
            $u = \App\Models\Usuario::where('email', $email)->first();
            if ($u) return Piloto::where('usuario_id', $u->id)->first();
        }
        return null;
    }

    /**
     * Mapeia payload do front para as colunas que EXISTEM na tabela `pilotos`.
     */
    protected function mapPayloadToDb(array $payload): array
    {
        $cols = $this->tableColumns();
        $out = [];

        $aliases = [
            // dados pessoais
            'cpf_piloto'  => ['cpf_piloto','cpf','id_piloto'],
            'nome_piloto' => ['nome_piloto','nome','name'],
            'email_piloto'=> ['email_piloto','email'],
            'numero_telefone' => ['numero_telefone','telefone','phone','celular'],
            'data_nascimento' => ['data_nascimento','nascimento','birthdate','dtNascimento'],
            'estado_civil'    => ['estado_civil','estadoCivil'],
            'tipo_sanguineo'  => ['tipo_sanguineo','tipoSanguineo'],

            // uploads (armazenamos apenas o “conteúdo”, tipo vai em *_tipo quando existir)
            'foto_piloto'     => ['foto_piloto','foto','avatar'],
            'foto_piloto_tipo'=> ['foto_piloto_tipo'],
            'foto_cnh'        => ['foto_cnh'],
            'foto_cnh_tipo'   => ['foto_cnh_tipo'],
            'termo_adesao'    => ['termo_adesao','termo'],
            'termo_adesao_tipo'=>['termo_adesao_tipo'],

            'usuario_id'      => ['usuario_id'],
            'id_piloto'       => ['id_piloto'],
        ];

        // aplica aliases somente se a coluna existir
        foreach ($aliases as $payloadKey => $dbCandidates) {
            if (!array_key_exists($payloadKey, $payload)) continue;
            foreach ($dbCandidates as $c) {
                if (in_array($c, $cols)) {
                    $out[$c] = $payload[$payloadKey];
                    break;
                }
            }
        }

        // inclui campos que já vierem com o mesmo nome da coluna
        foreach ($payload as $k => $v) {
            if (in_array($k, $cols) && !array_key_exists($k, $out)) $out[$k] = $v;
        }

        return $out;
    }

    /* =========================================================
     * Mídia e normalizações
     * =======================================================*/

    protected function stripDataUrl(string $maybeDataUrl): string
    {
        if (str_starts_with($maybeDataUrl, 'data:')) {
            [$meta, $raw] = explode(',', $maybeDataUrl, 2);
            return $raw;
        }
        return $maybeDataUrl;
    }

    /**
     * Persiste mídia. Se vier base64, salva como arquivo no storage público.
     * Retorna array com dados para gravar na coluna (base64 ou path).
     */
    protected function persistMedia(string $value, string $cpf, string $baseName, ?string $mime = null): array
    {
        $raw = $this->stripDataUrl($value);

        // se o conteúdo já for base64 “puro”, podemos gravar como base64 diretamente no banco (se preferir)
        if (preg_match('/^[A-Za-z0-9+\/=\r\n]+$/', substr($raw, 0, 120))) {
            // escolheremos salvar como arquivo físico para não inflar o banco
            // caímos para bloco abaixo que gera path
        }

        $map = [
            'image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp',
            'application/pdf'=>'pdf'
        ];
        $ext = $map[$mime ?? ''] ?? 'bin';

        $path = "public/pilotos/{$cpf}/{$baseName}.".$ext;
        try {
            Storage::put($path, base64_decode($raw));
            return ['db' => ['mode' => 'path', 'data' => Storage::url($path), 'mime' => $mime]];
        } catch (\Throwable $e) {
            Log::warning("Falha ao salvar mídia em disco: {$e->getMessage()}");
            // fallback: armazena base64
            return ['db' => ['mode'=>'base64','data'=>$raw,'mime'=>$mime]];
        }
    }

    protected function normalizeDate(?string $value): ?string
    {
        if (!$value) return null;
        try {
            if (preg_match('/^\d{2}\/\d{2}\/\d{4}$/', $value)) {
                [$d,$m,$y] = explode('/',$value); return "{$y}-{$m}-{$d}";
            }
            if (str_contains($value, 'T')) return substr($value, 0, 10);
            if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $value)) return $value;
        } catch (\Throwable $e) {
            Log::warning('normalizeDate falhou: '.$e->getMessage());
        }
        return null;
    }

    protected function normalizeUf(?string $v): ?string
    {
        if (!$v) return null;
        $s = strtoupper(preg_replace('/[^A-Za-z]/', '', $v));
        return strlen($s) >= 2 ? substr($s, 0, 2) : null;
    }

    /* =========================================================
     * Endereço (tabela `enderecos`)
     * =======================================================*/

    protected function upsertEndereco(string $cpf, array $payload): void
    {
        if (!Schema::hasTable('enderecos')) return;

        // pode vir “achatado” ou dentro de endereco.{campo}
        $src = $payload['endereco'] ?? [];
        $get = function(array $keys, $default = null) use ($payload, $src) {
            foreach ($keys as $k) {
                if (str_contains($k, '.')) {
                    [$prefix,$field] = explode('.', $k, 2);
                    if ($prefix === 'endereco' && array_key_exists($field, $src)) {
                        $v = $src[$field];
                        if ($v !== null && $v !== '') return $v;
                    }
                }
                if (array_key_exists($k, $payload) && $payload[$k] !== '') return $payload[$k];
            }
            return $default;
        };

        $tipo   = $get(['endereco.tipo_endereco','tipo_endereco'],'RESIDENCIAL');
        $cep    = $get(['endereco.cep','cep']);
        $numero = $get(['endereco.numero','numero']);
        $logr   = $get(['endereco.logradouro','logradouro']);
        $compl  = $get(['endereco.complemento','complemento']);
        $bairro = $get(['endereco.bairro','bairro']);
        $cidade = $get(['endereco.cidade','cidade']);
        $uf     = $get(['endereco.uf','uf']);
        $pais   = $get(['endereco.pais','pais'],'Brasil');
        if ($uf) $uf = $this->normalizeUf($uf);

        $temDados = false;
        foreach ([$cep,$numero,$logr,$compl,$bairro,$cidade,$uf,$pais] as $v) {
            if ($v !== null && $v !== '') { $temDados = true; break; }
        }
        if (!$temDados) return;

        try {
            DB::table('enderecos')->updateOrInsert(
                ['cpf_piloto'=>$cpf],
                [
                    'tipo_endereco'=>$tipo,
                    'cep'=>$cep,
                    'numero'=>$numero,
                    'logradouro'=>$logr,
                    'complemento'=>$compl,
                    'bairro'=>$bairro,
                    'cidade'=>$cidade,
                    'uf'=>$uf,
                    'pais'=>$pais,
                    'updated_at'=>now(),
                    'created_at'=>now(),
                ]
            );
        } catch (\Throwable $e) {
            Log::error('[Endereco] Erro ao salvar: '.$e->getMessage());
        }
    }

    protected function getEndereco(string $cpf): ?array
    {
        if (!Schema::hasTable('enderecos')) return null;
        $e = DB::table('enderecos')->where('cpf_piloto',$cpf)->first();
        return $e ? (array)$e : null;
    }

    /* =========================================================
     * Serialização para resposta
     * =======================================================*/

    protected function serializePiloto(Piloto $p): array
    {
        $resp = $p->toArray();

        // anexa endereço (se houver)
        $end = $this->getEndereco($p->cpf_piloto);
        if ($end) $resp['endereco'] = $end;

        // normaliza mídias: se for path, converte para base64 para o front reutilizar
        foreach (['foto_piloto','foto_cnh','termo_adesao'] as $field) {
            if (!empty($resp[$field])) {
                $resp[$field] = $this->toBase64ForResponse($resp[$field]) ?? $resp[$field];
            }
        }

        return $resp;
    }

    protected function toBase64ForResponse(?string $stored): ?string
    {
        if (!$stored) return null;

        $head = substr($stored, 0, 80);
        // heurística de base64 “puro”
        if (!str_starts_with($stored, '/storage/')
            && !str_starts_with($stored, 'public/')
            && preg_match('/^[A-Za-z0-9+\/=]+$/', $head)) {
            return preg_replace('/\s+/', '', $stored);
        }

        if (str_starts_with($stored, '/storage/')) {
            $rel = substr($stored, 9);
            $full = storage_path('app/public/'.$rel);
            if (is_file($full)) return base64_encode(file_get_contents($full));
            return null;
        }

        if (str_starts_with($stored, 'public/')) {
            $full = storage_path('app/'.$stored);
            if (is_file($full)) return base64_encode(file_get_contents($full));
            return null;
        }

        if (str_starts_with($stored, 'http://') || str_starts_with($stored, 'https://')) {
            try { $bin = @file_get_contents($stored); return $bin ? base64_encode($bin) : null; }
            catch (\Throwable $e) { Log::warning('Falha ao baixar mídia remota: '.$e->getMessage()); }
        }

        return null;
    }

    /* =========================================================
     * Endpoints
     * =======================================================*/

    public function index()
    {
        return Piloto::orderBy('id','desc')->get();
    }

    public function show($cpf)
    {
        $p = $this->findByCpf($cpf);
        if (!$p) return response()->json(['message'=>'Piloto não encontrado'],404);
        return response()->json($this->serializePiloto($p),200);
    }

    public function showByEmail($email)
    {
        $p = $this->findByEmail($email);
        if (!$p) return response()->json(['message'=>'Piloto não encontrado'],404);
        return response()->json($this->serializePiloto($p),200);
    }

    public function store(Request $request)
    {
        Log::debug('Piloto.store payload:', $request->all());

        $v = Validator::make($request->all(), [
            'cpf_piloto'  => 'required|string',
            'nome_piloto' => 'required|string',
            'email_piloto'=> 'nullable|email',
        ]);
        if ($v->fails()) return response()->json(['errors'=>$v->errors()],422);

        $payload = $request->all();

        // normalizações
        $payload['data_nascimento'] = $this->normalizeDate($payload['data_nascimento'] ?? null);

        // converte enums vindos como número de select para string (opcional)
        // estado_civil: (1=Solteiro,2=Casado,3=Viúvo,4=Outro)
        if (isset($payload['estado_civil']) && is_numeric($payload['estado_civil'])) {
            $map = [1=>'SOLTEIRO',2=>'CASADO',3=>'VIUVO',4=>'OUTRO'];
            $payload['estado_civil'] = $map[(int)$payload['estado_civil']] ?? (string)$payload['estado_civil'];
        }
        // tipo sanguíneo (1..8)
        if (isset($payload['tipo_sanguineo']) && is_numeric($payload['tipo_sanguineo'])) {
            $map = [1=>'A+',2=>'A-',3=>'B+',4=>'B-',5=>'AB+',6=>'AB-',7=>'O+',8=>'O-'];
            $payload['tipo_sanguineo'] = $map[(int)$payload['tipo_sanguineo']] ?? (string)$payload['tipo_sanguineo'];
        }

        $dbData = $this->mapPayloadToDb($payload);

        return DB::transaction(function () use ($payload, $dbData) {

            if ($this->findByCpf($payload['cpf_piloto'])) {
                return response()->json(['message'=>'Piloto com esse CPF já existe'],409);
            }

            $cpf = $payload['cpf_piloto'];

            // gera id_piloto se houver coluna e não vier do front
            if (Schema::hasColumn('pilotos','id_piloto') && empty($dbData['id_piloto'])) {
                $dbData['id_piloto'] = strtoupper("UTV-{$cpf}-".Str::random(4));
            }

            // mídias
            if (!empty($payload['foto_piloto'])) {
                $md = $this->persistMedia($payload['foto_piloto'], $cpf, 'foto_piloto', $payload['foto_piloto_tipo'] ?? 'image/jpeg');
                $dbData['foto_piloto'] = $md['db']['data'];
                if (Schema::hasColumn('pilotos','foto_piloto_tipo')) $dbData['foto_piloto_tipo'] = $md['db']['mime'] ?? null;
            }
            if (!empty($payload['foto_cnh'])) {
                $md = $this->persistMedia($payload['foto_cnh'], $cpf, 'foto_cnh', $payload['foto_cnh_tipo'] ?? 'application/pdf');
                $dbData['foto_cnh'] = $md['db']['data'];
                if (Schema::hasColumn('pilotos','foto_cnh_tipo')) $dbData['foto_cnh_tipo'] = $md['db']['mime'] ?? null;
            }
            if (!empty($payload['termo_adesao'])) {
                $md = $this->persistMedia($payload['termo_adesao'], $cpf, 'termo_adesao', $payload['termo_adesao_tipo'] ?? 'application/pdf');
                $dbData['termo_adesao'] = $md['db']['data'];
                if (Schema::hasColumn('pilotos','termo_adesao_tipo')) $dbData['termo_adesao_tipo'] = $md['db']['mime'] ?? null;
            }

            // cria piloto
            $piloto = Piloto::create($dbData);

            // salva/atualiza endereço na tabela enderecos
            $this->upsertEndereco($cpf, $payload);

            // HOTFIX: cria/associa usuário SEM tocar em tipo/tipo_usuario
            $emailToUse = $payload['email_piloto'] ?? $payload['email'] ?? null;
            $nomeToUse  = $payload['nome_piloto'] ?? $payload['nome'] ?? null;
            if ($emailToUse) {
                $usuario = Usuario::where('email',$emailToUse)->first();
                if (!$usuario) {
                    $default = env('DEFAULT_USER_PASSWORD','UtVLegal123!');
                    $u = new Usuario();
                    $u->nome  = $nomeToUse ?? $emailToUse;
                    $u->email = $emailToUse;
                    $u->senha = $default; // mutator grava em senha_hash
                    if (Schema::hasColumn('usuarios','is_active')) $u->is_active = 1;
                    if (Schema::hasColumn('usuarios','must_change_password')) $u->must_change_password = 1;
                    $u->save();
                    $usuario = $u;
                }
                if (Schema::hasColumn('pilotos','usuario_id')) {
                    $piloto->usuario_id = $usuario->id; $piloto->save();
                } elseif (Schema::hasColumn('pilotos','email_usuario')) {
                    $piloto->email_usuario = $usuario->email; $piloto->save();
                }
            }

            return response()->json(['piloto'=>$this->serializePiloto($piloto)],201);
        }, 1);
    }

    public function update(Request $request, $cpf)
    {
        Log::debug("Piloto.update payload for cpf {$cpf}:", $request->all());
        $piloto = $this->findByCpf($cpf);
        if (!$piloto) return response()->json(['message'=>'Piloto não encontrado'],404);

        $payload = $request->all();
        $payload['data_nascimento'] = $this->normalizeDate($payload['data_nascimento'] ?? null);

        if (isset($payload['estado_civil']) && is_numeric($payload['estado_civil'])) {
            $map = [1=>'SOLTEIRO',2=>'CASADO',3=>'VIUVO',4=>'OUTRO'];
            $payload['estado_civil'] = $map[(int)$payload['estado_civil']] ?? (string)$payload['estado_civil'];
        }
        if (isset($payload['tipo_sanguineo']) && is_numeric($payload['tipo_sanguineo'])) {
            $map = [1=>'A+',2=>'A-',3=>'B+',4=>'B-',5=>'AB+',6=>'AB-',7=>'O+',8=>'O-'];
            $payload['tipo_sanguineo'] = $map[(int)$payload['tipo_sanguineo']] ?? (string)$payload['tipo_sanguineo'];
        }

        $dbData = $this->mapPayloadToDb($payload);

        // mídias (se vierem no update)
        if (!empty($payload['foto_piloto'])) {
            $md = $this->persistMedia($payload['foto_piloto'], $cpf, 'foto_piloto', $payload['foto_piloto_tipo'] ?? 'image/jpeg');
            $dbData['foto_piloto'] = $md['db']['data'];
            if (Schema::hasColumn('pilotos','foto_piloto_tipo')) $dbData['foto_piloto_tipo'] = $md['db']['mime'] ?? null;
        }
        if (!empty($payload['foto_cnh'])) {
            $md = $this->persistMedia($payload['foto_cnh'], $cpf, 'foto_cnh', $payload['foto_cnh_tipo'] ?? 'application/pdf');
            $dbData['foto_cnh'] = $md['db']['data'];
            if (Schema::hasColumn('pilotos','foto_cnh_tipo')) $dbData['foto_cnh_tipo'] = $md['db']['mime'] ?? null;
        }
        if (!empty($payload['termo_adesao'])) {
            $md = $this->persistMedia($payload['termo_adesao'], $cpf, 'termo_adesao', $payload['termo_adesao_tipo'] ?? 'application/pdf');
            $dbData['termo_adesao'] = $md['db']['data'];
            if (Schema::hasColumn('pilotos','termo_adesao_tipo')) $dbData['termo_adesao_tipo'] = $md['db']['mime'] ?? null;
        }

        $piloto->update(array_filter($dbData, fn($v) => $v !== null));
        $this->upsertEndereco($cpf, $payload);

        // (opcional) re-associar usuário se e-mail mudou
        if (!empty($payload['email_piloto'])) {
            $usuario = Usuario::where('email',$payload['email_piloto'])->first();
            if ($usuario && Schema::hasColumn('pilotos','usuario_id')) {
                $piloto->usuario_id = $usuario->id; $piloto->save();
            }
        }

        return response()->json($this->serializePiloto($piloto->fresh()),200);
    }
}
