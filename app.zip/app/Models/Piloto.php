<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Piloto extends Model
{
    use HasFactory;

    protected $table = 'pilotos';
    public $timestamps = true;

    // Liste SOMENTE o que realmente existe na tabela `pilotos`
    protected $fillable = [
        // Identificação / dados pessoais
        'id_piloto',
        'cpf_piloto',
        'nome_piloto',
        'email_piloto',
        'numero_telefone',
        'data_nascimento',
        'estado_civil',
        'tipo_sanguineo',
        'usuario_id',

        // Uploads (paths no storage público)
        'foto_piloto',
        'foto_cnh',
        'termo_adesao',
        'termo_adesao_tipo',

        // QR Code (se existir no schema)
        'qrcode_path',
        'qrcode_hash',
    ];

    protected $casts = [
        'data_nascimento' => 'date:Y-m-d',
    ];

    /* ==========================
     |  Relationships
     |==========================*/
    public function usuario()
    {
        // Tabela `usuarios`, FK `usuario_id`
        return $this->belongsTo(Usuario::class, 'usuario_id');
    }

    /* ==========================
     |  Helpers
     |==========================*/

    /**
     * Escopo simples para busca por nome/CPF/e-mail/id_piloto.
     */
    public function scopeSearch($query, ?string $term)
    {
        if (!$term) return $query;

        $like = "%{$term}%";
        return $query->where(function ($q) use ($like) {
            $q->where('nome_piloto', 'like', $like)
              ->orWhere('cpf_piloto', 'like', $like)
              ->orWhere('email_piloto', 'like', $like)
              ->orWhere('id_piloto', 'like', $like);
        });
    }
}
