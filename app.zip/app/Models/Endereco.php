<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Endereco extends Model
{
    protected $table = 'enderecos';
    public $timestamps = true;

    // PK é o CPF; não é auto-incremento
    protected $primaryKey = 'cpf_piloto';
    public $incrementing = false;
    protected $keyType = 'string';

    protected $fillable = [
        'cpf_piloto',
        'tipo_endereco',
        'cep',
        'numero',
        'logradouro',
        'complemento',
        'bairro',
        'cidade',
        'uf',
        'pais',
    ];

    // relação opcional por CPF (se quiser navegar do endereço para o piloto)
    public function piloto()
    {
        return $this->belongsTo(\App\Models\Piloto::class, 'cpf_piloto', 'cpf_piloto');
    }
}
