export const EstadosBrasileiros = {
  Acre: "AC",
  Alagoas: "AL",
  Amapá: "AP",
  Amazonas: "AM",
  Bahia: "BA",
  Ceará: "CE",
  "Distrito Federal": "DF",
  "Espírito Santo": "ES",
  Goiás: "GO",
  Maranhão: "MA",
  "Mato Grosso": "MT",
  "Mato Grosso do Sul": "MS",
  "Minas Gerais": "MG",
  Pará: "PA",
  Paraíba: "PB",
  Paraná: "PR",
  Pernambuco: "PE",
  Piauí: "PI",
  "Rio de Janeiro": "RJ",
  "Rio Grande do Norte": "RN",
  "Rio Grande do Sul": "RS",
  Rondônia: "RO",
  Roraima: "RR",
  "Santa Catarina": "SC",
  "São Paulo": "SP",
  Sergipe: "SE",
  Tocantins: "TO",
};

export const TipoEndereco = {
  RESIDENCIAL: "RESIDENCIAL",
  COMERCIAL: "COMERCIAL",
  OUTRO: "OUTRO",
};

export const EstadoCivil = {
  SOLTEIRO: 1,
  CASADO: 2,
  VIUVO: 3,
  OUTROS: 4,
};

export const TipoSanguineo = {
  A_POSITIVO: 1,
  A_NEGATIVO: 2,
  B_POSITIVO: 3,
  B_NEGATIVO: 4,
  AB_POSITIVO: 5,
  AB_NEGATIVO: 6,
  O_POSITIVO: 7,
  O_NEGATIVO: 8,
};
