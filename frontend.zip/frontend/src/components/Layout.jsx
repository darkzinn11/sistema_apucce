import { useState, useEffect } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import {
  getUserRole,
  getCurrentUser,
  isAuthenticated,
} from "../services/authService";
import Loading from "./Loading";

const Layout = ({ children }) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [userRole, setUserRole] = useState(null);
  const [userEmail, setUserEmail] = useState("");
  const [isLoading, setIsLoading] = useState(true);
  const navigate = useNavigate();
  const location = useLocation();

  // Verificar autenticação e permissões
  useEffect(() => {
    const checkAuth = () => {
      if (!isAuthenticated()) {
        // Se não estiver autenticado, redirecionar para login
        navigate("/");
        return;
      }

      const role = getUserRole();
      const user = getCurrentUser();

      setUserRole(role);
      setUserEmail(user?.email || "");

      // Verificar permissões para rotas específicas
      if (location.pathname.startsWith("/administracao") && role !== "ADMIN") {
        alert("Acesso restrito a administradores");
        navigate("/home");
        return;
      }

      if (
        location.pathname.startsWith("/fiscalizacao") &&
        !(role === "ADMIN" || role === "FISCAL")
      ) {
        alert("Acesso restrito a administradores e fiscais");
        navigate("/home");
        return;
      }

      setIsLoading(false);
    };

    checkAuth();
  }, [navigate, location.pathname]);

  const handleNavigation = (path) => {
    navigate(path);
    setIsMenuOpen(false);
  };

  const handleLogout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("user");
    navigate("/");
  };

  // Se estiver carregando, mostrar spinner
  if (isLoading) {
    return <Loading message="Verificando autenticação..." />;
  }

  // Não mostrar layout na página de login
  if (location.pathname === "/") {
    return <>{children}</>;
  }

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Header */}
      <header className="bg-gray-800 text-white shadow-lg">
        <div className="container mx-auto px-4 py-3 flex justify-between items-center">
          <div
            className="flex items-center cursor-pointer"
            onClick={() => handleNavigation("/home")}
          >
            {/* Compact title for small screens, full title for md+ */}
            <h1 className="text-xl font-bold">
              <span className="md:hidden">UTV</span>
              <span className="hidden md:inline">UTV LEGAL</span>
            </h1>
            <span className="text-blue-100 ml-2 text-sm">
              <span className="md:hidden">Gestão UTV</span>
              <span className="hidden md:inline">Gestão de veículos de tração</span>
            </span>
          </div>

          <div className="flex items-center space-x-4">
            <span className="text-sm hidden md:block">
              {userEmail} ({userRole})
            </span>

            {/* Menu hamburger para todos os dispositivos */}
            <div className="relative">
              <button
                className="p-2 rounded-md hover:bg-gray-700 transition-colors"
                onClick={() => setIsMenuOpen(!isMenuOpen)}
              >
                <svg
                  className="w-6 h-6"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M4 6h16M4 12h16M4 18h16"
                  />
                </svg>
              </button>

              {/* Menu dropdown para todos os dispositivos */}
              {isMenuOpen && (
                <div className="absolute right-0 mt-2 w-56 bg-gray-700 rounded-md shadow-lg py-1 z-50">
                  <nav className="flex flex-col">
                    <div className="px-4 py-2 text-sm border-b border-gray-600">
                      {userEmail}{" "}
                      <span className="text-blue-300">({userRole})</span>
                    </div>

                    {(userRole === "ADMIN" || userRole === "FISCAL") && (
                      <button
                        onClick={() => handleNavigation("/fiscalizacao")}
                        className={`px-4 py-2 text-left hover:bg-gray-600 transition-colors ${
                          location.pathname === "/fiscalizacao"
                            ? "bg-gray-600"
                            : ""
                        }`}
                      >
                        Fiscalização
                      </button>
                    )}

                    {userRole === "ADMIN" && (
                      <>
                        <button
                          onClick={() => handleNavigation("/pilotos")}
                          className={`px-4 py-2 text-left hover:bg-gray-600 transition-colors ${
                            location.pathname === "/pilotos"
                              ? "bg-gray-600"
                              : ""
                          }`}
                        >
                          Pilotos
                        </button>
                        <button
                          onClick={() => handleNavigation("/usuarios")}
                          className={`px-4 py-2 text-left hover:bg-gray-600 transition-colors ${
                            location.pathname === "/usuarios"
                              ? "bg-gray-600"
                              : ""
                          }`}
                        >
                          Usuários
                        </button>
                      </>
                    )}

                    {/* Apenas USER tem acesso a "Meus Dados" */}
                    {userRole === "USER" && (
                      <button
                        onClick={() => handleNavigation("/meus-dados")}
                        className={`px-4 py-2 text-left hover:bg-gray-600 transition-colors ${
                          location.pathname === "/meus-dados"
                            ? "bg-gray-600"
                            : ""
                        }`}
                      >
                        Meus Dados
                      </button>
                    )}

                    <div className="border-t border-gray-600 mt-1"></div>

                    <button
                      onClick={handleLogout}
                      className="px-4 py-2 text-left text-red-300 hover:bg-red-700 hover:text-white transition-colors mt-1"
                    >
                      Sair
                    </button>
                  </nav>
                </div>
              )}
            </div>
          </div>
        </div>
      </header>

      {/* Conteúdo principal */}
      <main className="container mx-auto px-4 py-6">{children}</main>

      {/* Footer */}
      <footer className="bg-white border-t border-gray-200 mt-8">
        <div className="container mx-auto px-4 py-6 flex flex-col md:flex-row items-center justify-between text-sm text-gray-600">
          <div className="mb-3 md:mb-0 text-center md:text-left">
            <strong className="text-gray-800">UTV LEGAL</strong>
            <div>Gestão de veículos de tração</div>
            <div className="mt-1">© {new Date().getFullYear()} UTV LEGAL. Todos os direitos reservados.</div>
          </div>

          <div className="flex flex-col sm:flex-row items-center gap-3">
            <button
              onClick={() => handleNavigation('/home')}
              className="text-gray-600 hover:text-gray-900"
            >
              Início
            </button>

            {(userRole === 'ADMIN' || userRole === 'FISCAL') && (
              <button
                onClick={() => handleNavigation('/fiscalizacao')}
                className="text-gray-600 hover:text-gray-900"
              >
                Fiscalização
              </button>
            )}

            {userRole === 'ADMIN' && (
              <>
                <button
                  onClick={() => handleNavigation('/usuarios')}
                  className="text-gray-600 hover:text-gray-900"
                >
                  Usuários
                </button>
                <button
                  onClick={() => handleNavigation('/pilotos')}
                  className="text-gray-600 hover:text-gray-900"
                >
                  Pilotos
                </button>
              </>
            )}
          </div>
        </div>
      </footer>

      {/* Overlay para fechar o menu ao clicar fora */}
      {isMenuOpen && (
        <div
          className="fixed inset-0 z-40"
          onClick={() => setIsMenuOpen(false)}
        ></div>
      )}
    </div>
  );
};

export default Layout;
