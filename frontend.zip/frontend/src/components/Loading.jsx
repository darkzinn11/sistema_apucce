import PropTypes from "prop-types";

const Loading = ({
  fullScreen = true,
  message = "Carregando...",
  size = "md",
  type = "spinner",
}) => {
  const sizes = {
    sm: "h-8 w-8",
    md: "h-12 w-12",
    lg: "h-16 w-16",
  };

  const loaders = {
    spinner: (
      <div
        className={`animate-spin rounded-full border-t-2 border-b-2 border-blue-500 ${sizes[size]}`}
      ></div>
    ),
    dots: (
      <div className="flex space-x-2">
        {[...Array(3)].map((_, i) => (
          <div
            key={i}
            className={`${sizes[size]
              .replace("h-", "h-")
              .replace("w-", "w-")} bg-blue-500 rounded-full animate-bounce`}
            style={{ animationDelay: `${i * 0.1}s` }}
          ></div>
        ))}
      </div>
    ),
  };

  const content = (
    <div className="flex flex-col items-center">
      {loaders[type]}
      {message && <p className="text-gray-700 mt-4">{message}</p>}
    </div>
  );

  return fullScreen ? (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white p-6 rounded-lg shadow-lg">{content}</div>
    </div>
  ) : (
    content
  );
};

Loading.propTypes = {
  fullScreen: PropTypes.bool,
  message: PropTypes.string,
  size: PropTypes.oneOf(["sm", "md", "lg"]),
  type: PropTypes.oneOf(["spinner", "dots"]),
};

export default Loading;
