// src/App.jsx
import { createBrowserRouter, RouterProvider, Navigate } from "react-router-dom";
import { useEffect, useState } from "react";
import axios from "axios";

import ListaPilotos from "./pages/Pilotos/ListaPilotos";
import CadastroPiloto from "./pages/Pilotos/CadastroPiloto";
import ErrorPage from "./pages/ErrorPage";
import Fiscalizacao from "./pages/Fiscalizacao";
import Home from "./pages/Home";
import CriarUsuario from "./pages/Usuarios/CriarUsuario";
import ListaUsuarios from "./pages/Usuarios/ListaUsuarios";
import Login from "./pages/Login";
import MeusDados from "./pages/MeusDados";
import MudarSenha from "./pages/MudarSenha"; // <— NOVO
import Layout from "./components/Layout";

import { isAuthenticated, getUserRole, getToken } from "./services/authService";
import { API_URL } from "./utils/apiUrl";

// Guard básico de autenticação
const RequireAuth = ({ children }) =>
  isAuthenticated() ? children : <Navigate to="/" replace />;

// Guard de papel (role)
const RequireRole = ({ roles = [], children }) => {
  const authed = isAuthenticated();
  const role = (getUserRole() || "").toUpperCase();
  if (!authed) return <Navigate to="/" replace />;
  return roles.includes(role) ? children : <Navigate to="/home" replace />;
};

// Guard que obriga troca de senha
const RequirePasswordChange = ({ children }) => {
  const [checking, setChecking] = useState(true);
  const [mustChange, setMustChange] = useState(false);

  useEffect(() => {
    let alive = true;
    const token = getToken();
    if (!token) {
      setChecking(false);
      return;
    }
    axios
      .get(`${API_URL}/me`, {
        headers: { Authorization: `Bearer ${token}` },
      })
      .then((res) => {
        if (!alive) return;
        setMustChange(!!res.data?.must_change_password);
      })
      .catch(() => {
        // se der 401/erro, deixa outro guard (RequireAuth) resolver
      })
      .finally(() => {
        if (alive) setChecking(false);
      });
    return () => {
      alive = false;
    };
  }, []);

  // pode trocar por um spinner se quiser
  if (checking) return null;

  if (mustChange) {
    return <Navigate to="/mudar-senha" replace />;
  }
  return children;
};

// Rotas
const router = createBrowserRouter([
  // Login (público)
  { path: "/", element: <Login />, errorElement: <ErrorPage /> },

  // Página de trocar senha — precisa estar autenticado,
  // mas NÃO deve passar pelo RequirePasswordChange (senão entra em loop).
  {
    path: "/mudar-senha",
    element: (
      <RequireAuth>
        <Layout>
          <MudarSenha />
        </Layout>
      </RequireAuth>
    ),
    errorElement: <ErrorPage />,
  },

  // Home
  {
    path: "/home",
    element: (
      <RequireAuth>
        <RequirePasswordChange>
          <Layout>
            <Home />
          </Layout>
        </RequirePasswordChange>
      </RequireAuth>
    ),
    errorElement: <ErrorPage />,
  },

  // Pilotos - list
  {
    path: "/pilotos",
    element: (
      <RequireRole roles={["ADMIN"]}>
        <RequirePasswordChange>
          <Layout>
            <ListaPilotos />
          </Layout>
        </RequirePasswordChange>
      </RequireRole>
    ),
    errorElement: <ErrorPage />,
  },

  /**
   * Cadastro / Edição de Piloto
   */
  {
    path: "/pilotos/cadastro",
    element: (
      <RequireRole roles={["ADMIN"]}>
        <RequirePasswordChange>
          <Layout>
            <CadastroPiloto />
          </Layout>
        </RequirePasswordChange>
      </RequireRole>
    ),
    errorElement: <ErrorPage />,
  },
  {
    path: "/pilotos/cadastro/:cpf",
    element: (
      <RequireRole roles={["ADMIN"]}>
        <RequirePasswordChange>
          <Layout>
            <CadastroPiloto />
          </Layout>
        </RequirePasswordChange>
      </RequireRole>
    ),
    errorElement: <ErrorPage />,
  },
  {
    path: "/pilotos/detalhes",
    element: (
      <RequireRole roles={["ADMIN"]}>
        <RequirePasswordChange>
          <Layout>
            <CadastroPiloto />
          </Layout>
        </RequirePasswordChange>
      </RequireRole>
    ),
    errorElement: <ErrorPage />,
  },

  // Usuários - list
  {
    path: "/usuarios",
    element: (
      <RequireRole roles={["ADMIN"]}>
        <RequirePasswordChange>
          <Layout>
            <ListaUsuarios />
          </Layout>
        </RequirePasswordChange>
      </RequireRole>
    ),
    errorElement: <ErrorPage />,
  },

  // Usuários - cadastro/edição
  {
    path: "/usuarios/cadastro-usuarios",
    element: (
      <RequireRole roles={["ADMIN"]}>
        <RequirePasswordChange>
          <Layout>
            <CriarUsuario />
          </Layout>
        </RequirePasswordChange>
      </RequireRole>
    ),
    errorElement: <ErrorPage />,
  },
  {
    path: "/usuarios/cadastro",
    element: (
      <RequireRole roles={["ADMIN"]}>
        <RequirePasswordChange>
          <Layout>
            <CriarUsuario />
          </Layout>
        </RequirePasswordChange>
      </RequireRole>
    ),
    errorElement: <ErrorPage />,
  },
  {
    path: "/usuarios/cadastro/:email",
    element: (
      <RequireRole roles={["ADMIN"]}>
        <RequirePasswordChange>
          <Layout>
            <CriarUsuario />
          </Layout>
        </RequirePasswordChange>
      </RequireRole>
    ),
    errorElement: <ErrorPage />,
  },

  // Fiscalização
  {
    path: "/fiscalizacao",
    element: (
      <RequireRole roles={["ADMIN", "FISCAL"]}>
        <RequirePasswordChange>
          <Layout>
            <Fiscalizacao />
          </Layout>
        </RequirePasswordChange>
      </RequireRole>
    ),
    errorElement: <ErrorPage />,
  },

  // Meus dados
  {
    path: "/meus-dados",
    element: (
      <RequireAuth>
        <RequirePasswordChange>
          <Layout>
            <MeusDados />
          </Layout>
        </RequirePasswordChange>
      </RequireAuth>
    ),
    errorElement: <ErrorPage />,
  },

  // 404
  { path: "*", element: <ErrorPage /> },
]);

export default function App() {
  return <RouterProvider router={router} />;
}
