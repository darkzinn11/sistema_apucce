// src/services/authService.js
import api from "./api";

// Login (POST JSON ou form, use o que já estiver funcionando)
export const login = async (email, password) => {
  const body = new URLSearchParams();
  body.append("username", email);
  body.append("password", password);

  const { data } = await api.post("/auth/login", body, {
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
  });
  // data: { access_token, user: { id, nome, email, tipo } }

  // Normalize aqui
  const normalizedUser = {
    id: data.user?.id,
    nome: data.user?.nome,
    email: data.user?.email,
    // força UPPERCASE
    tipo: String(data.user?.tipo || "").toUpperCase(),
  };

  localStorage.setItem("token", data.access_token);
  localStorage.setItem("user", JSON.stringify(normalizedUser));
  return data;
};

export const logout = () => {
  localStorage.removeItem("token");
  localStorage.removeItem("user");
};

export const getToken = () => localStorage.getItem("token");

export const getUser = () => {
  const u = localStorage.getItem("user");
  return u ? JSON.parse(u) : null;
};

export const getCurrentUser = getUser;

export const getUserRole = () => {
  const u = getUser();
  // sempre devolve em UPPERCASE
  return u?.tipo ? String(u.tipo).toUpperCase() : null;
};

// comparação case-insensitive
export const hasRole = (role) => {
  const r = getUserRole(); // já vem em UPPER
  return !!r && r === String(role).toUpperCase();
};

export const isAuthenticated = () => !!getToken();
