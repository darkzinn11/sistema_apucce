import { useState } from "react";
import { useNavigate } from "react-router-dom";
import Loading from "../../components/Loading";
import { login } from "../../services/authService";

// Caminhos para as imagens na pasta `public`
const logoUrl = '/logo.png';
const backgroundImageUrl = '/foto1.jpeg';

const Login = () => {
  const navigate = useNavigate();

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setIsLoading(true);

    try {
      const resp = await login(email, password);
      localStorage.setItem("token", resp.access_token);
      localStorage.setItem("user", JSON.stringify(resp.user));

      const pendingPilotoId = sessionStorage.getItem("pendingPilotoId");
      const redirectUrl = sessionStorage.getItem("redirectAfterLogin");

      if (pendingPilotoId) {
        sessionStorage.removeItem("pendingPilotoId");
        navigate(`/fiscalizacao?idPiloto=${pendingPilotoId}`);
      } else if (redirectUrl) {
        sessionStorage.removeItem("redirectAfterLogin");
        navigate(redirectUrl);
      } else {
        navigate("/home");
      }
    } catch (err) {
      const msg = err?.message || "Erro ao fazer login. Verifique seus dados e tente novamente.";
      setError(msg);
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-slate-900 flex items-center justify-center">
        <Loading message="Fazendo login..." />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex">
      {/* Coluna Esquerda - Formulário (COM AS CORES CORRIGIDAS) */}
      <div className="w-full md:w-1/2 bg-slate-950 flex items-center justify-center p-8">
        <div className="max-w-sm w-full bg-white rounded-xl shadow-lg p-8">
          <div className="flex justify-center mb-6">
            <img src={logoUrl} alt="Logo APUC" className="h-32" />
          </div>
          <h2 className="text-xl font-bold text-center text-gray-700 mb-8">
            Acesse o UTV Legal
          </h2>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label className="text-xs font-bold text-gray-500 tracking-wide" htmlFor="email">
                USUÁRIO
              </label>
              <input
                id="email"
                type="text"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                autoComplete="username"
                className="w-full text-gray-800 text-lg py-2 border-b-2 border-gray-300 focus:outline-none focus:border-blue-500 bg-slate-100 rounded-md px-3"
                required
              />
            </div>

            <div>
              <label className="text-xs font-bold text-gray-500 tracking-wide" htmlFor="password">
                SENHA
              </label>
              <input
                id="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                autoComplete="current-password"
                className="w-full text-gray-800 text-lg py-2 border-b-2 border-gray-300 focus:outline-none focus:border-blue-500 bg-slate-100 rounded-md px-3"
                required
              />
            </div>
            
            <div className="flex items-center justify-between text-xs">
              <div className="flex items-center">
                <input id="manterConectado" type="checkbox" className="h-4 w-4 text-green-600 focus:ring-green-500 border-gray-300 rounded" />
                <label htmlFor="manterConectado" className="ml-2 text-gray-600">Manter Conectado</label>
              </div>
              <a href="#" className="font-medium text-gray-600 hover:text-green-500">
                Recuperar Senha
              </a>
            </div>

            {error && <p className="text-red-500 text-sm text-center font-semibold">{error}</p>}

            <div>
              <button
                type="submit"
                disabled={isLoading}
                className="w-full flex justify-center bg-green-500 hover:bg-green-600 text-white p-3 rounded-lg tracking-wide font-semibold cursor-pointer transition ease-in duration-300 disabled:opacity-50"
              >
                ENTRAR
              </button>
            </div>
          </form>
        </div>
      </div>

      {/* Coluna Direita - Imagem */}
      <div
        className="hidden md:block w-1/2 bg-cover bg-center"
        style={{ backgroundImage: `url(${backgroundImageUrl})` }}
      ></div>
    </div>
  );
};

export default Login;