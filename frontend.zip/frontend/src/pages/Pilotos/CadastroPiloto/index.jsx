// src/pages/Pilotos/CadastroPiloto/index.jsx
import axios from "axios";
import { useEffect, useState } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import Loading from "../../../components/Loading.jsx";
import { API_URL } from "../../../utils/apiUrl.js";
import { EstadosBrasileiros } from "../../../utils/enums.js";
import { getUserRole, getToken } from "../../../services/authService.js";

const CadastroPiloto = () => {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const cpf = searchParams.get("cpf");
  const [isUpdate, setIsUpdate] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [lastSaveError, setLastSaveError] = useState("");

  const [formData, setFormData] = useState({
    nome: "",
    cpfPiloto: "",
    dtNascimento: "",
    tipoSanguineo: "",
    email: "",
    celular: "",
    estadoCivil: "",
    contatoEmergencia: "",
    telefoneEmergencia: "",
    planoSaude: "",
    fotoPiloto: null,
    termoAdesao: null,
    fotoCarteira: null,
    idPiloto: "", // mantemos no state apenas para exibição quando for update
    tipoEndereco: "RESIDENCIAL",
    cep: "",
    logradouro: "",
    numero: "",
    complemento: "",
    bairro: "",
    cidade: "",
    uf: "",
    pais: "Brasil",
    fotoFrente: null,
    fotoTras: null,
    fotoEsquerda: null,
    fotoDireita: null,
    notaFiscal: null,
  });

  const [dropdownAberto, setDropdownAberto] = useState({
    dadosPessoais: true,
    endereco: true,
    carro: true,
  });

  useEffect(() => {
    const role = getUserRole();
    if (role !== "ADMIN") {
      alert("Acesso restrito a administradores");
      navigate("/home");
      return;
    }
  }, [navigate]);

  const toggleDropdown = (secao) =>
    setDropdownAberto((prev) => ({ ...prev, [secao]: !prev[secao] }));

  /**
   * base64ToFile: função robusta que:
   * - se receber 'data:...' usa diretamente
   * - se receber URL relativa (/storage/..) ou absoluta (http...) faz fetch dessa URL
   * - se receber raw base64 (sem prefixo) monta 'data:${mime};base64,' + base64
   * Retorna File ou null.
   */
  const base64ToFile = async (base64OrPath, filename = "file.bin", mimeGuess = "application/octet-stream") => {
    if (!base64OrPath) return null;
    try {
      if (typeof base64OrPath === "string" && base64OrPath.startsWith("data:")) {
        const res = await fetch(base64OrPath);
        const blob = await res.blob();
        return new File([blob], filename, { type: blob.type || mimeGuess });
      }
      if (typeof base64OrPath === "string" && (base64OrPath.startsWith("http://") || base64OrPath.startsWith("https://"))) {
        const res = await fetch(base64OrPath);
        const blob = await res.blob();
        return new File([blob], filename, { type: blob.type || mimeGuess });
      }
      if (typeof base64OrPath === "string" && (base64OrPath.startsWith("/") || base64OrPath.startsWith("storage/"))) {
        const maybeUrl = base64OrPath.startsWith("/") ? `${window.location.origin}${base64OrPath}` : `${window.location.origin}/${base64OrPath}`;
        const res = await fetch(maybeUrl);
        const blob = await res.blob();
        return new File([blob], filename, { type: blob.type || mimeGuess });
      }
      if (typeof base64OrPath === "string" && base64OrPath.includes("/storage/")) {
        const idx = base64OrPath.indexOf("/storage/");
        const path = base64OrPath.slice(idx);
        const url = `${window.location.origin}${path}`;
        const res = await fetch(url);
        const blob = await res.blob();
        return new File([blob], filename, { type: blob.type || mimeGuess });
      }
      if (typeof base64OrPath === "string") {
        const dataUrl = `data:${mimeGuess};base64,${base64OrPath}`;
        const res = await fetch(dataUrl);
        const blob = await res.blob();
        return new File([blob], filename, { type: blob.type || mimeGuess });
      }
      return null;
    } catch (err) {
      console.error("base64ToFile falhou para:", base64OrPath, err);
      return null;
    }
  };

  const getPilot = async (cpfParam) => {
    setIsLoading(true);
    setLastSaveError("");
    try {
      const res = await axios.get(`${API_URL}/pilotos/${encodeURIComponent(cpfParam)}`, {
        headers: { Authorization: `Bearer ${getToken()}` },
      });
      const piloto = res.data || {};

      setFormData((prev) => ({
        ...prev,
        nome: piloto.nome_piloto ?? piloto.nome ?? "",
        cpfPiloto: piloto.cpf_piloto ?? prev.cpfPiloto ?? "",
        dtNascimento: piloto.data_nascimento ? formatISOToDisplay(piloto.data_nascimento) : prev.dtNascimento ?? "",
        tipoSanguineo: piloto.tipo_sanguineo ?? prev.tipoSanguineo ?? "",
        email: piloto.email_piloto ?? piloto.email ?? "",
        celular: piloto.numero_telefone ?? prev.celular ?? "",
        estadoCivil: piloto.estado_civil ?? prev.estadoCivil ?? "",
        contatoEmergencia: piloto.nome_contato_seguranca ?? prev.contatoEmergencia ?? "",
        telefoneEmergencia: piloto.numero_contato_seguranca ?? prev.telefoneEmergencia ?? "",
        planoSaude: piloto.nome_plano_saude ?? prev.planoSaude ?? "",
        idPiloto: piloto.id_piloto ?? prev.idPiloto ?? "",
      }));

      // arquivos pessoais (se vierem)
      if (piloto.termo_adesao) {
        const f = await base64ToFile(piloto.termo_adesao, "termo_adesao.pdf", piloto.termo_adesao_tipo ?? "application/pdf");
        if (f) setFormData((prev) => ({ ...prev, termoAdesao: f }));
      }
      if (piloto.foto_piloto) {
        const f = await base64ToFile(piloto.foto_piloto, "foto_piloto.jpg", piloto.foto_piloto_tipo ?? "image/jpeg");
        if (f) setFormData((prev) => ({ ...prev, fotoPiloto: f }));
      }
      if (piloto.foto_cnh) {
        const f = await base64ToFile(piloto.foto_cnh, "foto_cnh.pdf", piloto.foto_cnh_tipo ?? "application/pdf");
        if (f) setFormData((prev) => ({ ...prev, fotoCarteira: f }));
      }
    } catch (err) {
      console.error("Erro ao buscar piloto:", err);
    } finally {
      setIsLoading(false);
    }
  };

  const getEndereco = async (cpfParam) => {
    try {
      const res = await axios.get(`${API_URL}/endereco/${encodeURIComponent(cpfParam)}`, {
        headers: { Authorization: `Bearer ${getToken()}` },
      });
      const e = res.data || {};
      setFormData((prev) => ({
        ...prev,
        tipoEndereco: e.tipo_endereco ?? prev.tipoEndereco ?? "RESIDENCIAL",
        cep: e.cep ?? prev.cep ?? "",
        logradouro: e.logradouro ?? prev.logradouro ?? "",
        numero: e.numero ?? prev.numero ?? "",
        complemento: e.complemento ?? prev.complemento ?? "",
        bairro: e.bairro ?? prev.bairro ?? "",
        cidade: e.cidade ?? prev.cidade ?? "",
        uf: e.uf ?? prev.uf ?? "",
        pais: e.pais ?? prev.pais ?? "Brasil",
      }));
    } catch (err) {
      if (err.response?.status !== 404) console.error("Erro ao buscar endereço:", err);
    }
  };

  const getCar = async (cpfParam) => {
    try {
      const res = await axios.get(`${API_URL}/carros/${encodeURIComponent(cpfParam)}`, {
        headers: { Authorization: `Bearer ${getToken()}` },
      });
      const carro = res.data || {};
      const arquivos = {};
      if (carro.foto_frente) arquivos.fotoFrente = await base64ToFile(carro.foto_frente, "foto_frente.jpg", carro.foto_frente_tipo ?? "image/jpeg");
      if (carro.foto_tras) arquivos.fotoTras = await base64ToFile(carro.foto_tras, "foto_tras.jpg", carro.foto_tras_tipo ?? "image/jpeg");
      if (carro.foto_esquerda) arquivos.fotoEsquerda = await base64ToFile(carro.foto_esquerda, "foto_esquerda.jpg", carro.foto_esquerda_tipo ?? "image/jpeg");
      if (carro.foto_direita) arquivos.fotoDireita = await base64ToFile(carro.foto_direita, "foto_direita.jpg", carro.foto_direita_tipo ?? "image/jpeg");
      if (carro.nota_fiscal) arquivos.notaFiscal = await base64ToFile(carro.nota_fiscal, "nota_fiscal.pdf", carro.nota_fiscal_tipo ?? "application/pdf");
      setFormData((prev) => ({ ...prev, ...arquivos }));
    } catch (err) {
      if (err.response?.status !== 404) console.error("Erro ao buscar carro:", err);
    }
  };

  useEffect(() => {
    if (cpf) {
      setIsUpdate(true);
      (async () => {
        await getPilot(cpf);
        await getEndereco(cpf);
        await getCar(cpf);
      })();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [cpf]);

  const handleChange = (e) => {
    const { name, value, files } = e.target;
    if (files) {
      setFormData((prev) => ({ ...prev, [name]: files[0] }));
    } else {
      setFormData((prev) => ({ ...prev, [name]: value }));
    }
  };

  const resetForm = () => {
    setFormData({
      nome: "",
      cpfPiloto: "",
      dtNascimento: "",
      tipoSanguineo: "",
      email: "",
      celular: "",
      estadoCivil: "",
      contatoEmergencia: "",
      telefoneEmergencia: "",
      planoSaude: "",
      fotoPiloto: null,
      termoAdesao: null,
      fotoCarteira: null,
      idPiloto: "",
      tipoEndereco: "RESIDENCIAL",
      cep: "",
      logradouro: "",
      numero: "",
      complemento: "",
      bairro: "",
      cidade: "",
      uf: "",
      pais: "Brasil",
      fotoFrente: null,
      fotoTras: null,
      fotoEsquerda: null,
      fotoDireita: null,
      notaFiscal: null,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    try {
      const fileToBase64 = async (file) => {
        if (!file) return null;
        return await new Promise((resolve, reject) => {
          const reader = new FileReader();
          reader.readAsDataURL(file);
          reader.onload = () => resolve(reader.result.split(",")[1]);
          reader.onerror = (error) => reject(error);
        });
      };

      const data_nascimento = formData.dtNascimento ? formatDateToISO(formData.dtNascimento) : null;
      const fotoPilotoBase64 = await fileToBase64(formData.fotoPiloto);
      const fotoCarteiraBase64 = await fileToBase64(formData.fotoCarteira);
      const termoAdesaoBase64 = await fileToBase64(formData.termoAdesao);

      // OBS: Removi id_piloto do payload — o sistema deve gerar.
      const payload = {
        cpf_piloto: formData.cpfPiloto,
        nome_piloto: formData.nome,
        email_piloto: formData.email,
        numero_telefone: formData.celular,
        data_nascimento: data_nascimento,
        estado_civil: formData.estadoCivil ? parseInt(formData.estadoCivil) : null,
        nome_contato_seguranca: formData.contatoEmergencia,
        numero_contato_seguranca: formData.telefoneEmergencia,
        tipo_sanguineo: formData.tipoSanguineo ? parseInt(formData.tipoSanguineo) : null,
        nome_plano_saude: formData.planoSaude,
        foto_piloto: fotoPilotoBase64,
        foto_cnh: fotoCarteiraBase64,
        foto_cnh_tipo: formData.fotoCarteira ? "application/pdf" : null,
        termo_adesao: termoAdesaoBase64,
        termo_adesao_tipo: formData.termoAdesao ? "application/pdf" : null,
        // id_piloto intentionally omitted so backend generates it
      };

      const method = isUpdate ? "put" : "post";
      const url = isUpdate ? `${API_URL}/pilotos/${encodeURIComponent(formData.cpfPiloto)}` : `${API_URL}/pilotos/`;

      // **** MUDANÇA PRINCIPAL: capturar a resposta do backend para ler temp_password ****
      const resPiloto = await axios({
        method,
        url,
        data: payload,
        headers: { Authorization: `Bearer ${getToken()}`, "Content-Type": "application/json" },
      });

      // backend pode retornar temp_password em alguns formatos; tenta localizar
      const data = resPiloto.data || {};
      const tempPasswordCandidates = [
        data.temp_password,
        data.tempPassword,
        data.password,
        data.senha_temp,
        data.usuario?.temp_password,
        data.usuario?.tempPassword,
        data.usuario?.password,
        data.piloto?.temp_password,
        data.piloto?.tempPassword,
      ];
      const tempPassword = tempPasswordCandidates.find(Boolean);

      if (tempPassword) {
        // tenta copiar para área de transferência (quando disponível)
        try {
          if (navigator.clipboard && navigator.clipboard.writeText) {
            await navigator.clipboard.writeText(String(tempPassword));
            alert(`Piloto ${formData.nome} salvo com sucesso!\nSenha temporária copiada para a área de transferência:\n${tempPassword}\n\nEnvie essa senha ao piloto por canal seguro.`);
          } else {
            // fallback simples
            alert(`Piloto ${formData.nome} salvo com sucesso!\nSenha temporária: ${tempPassword}\n(Copie e encaminhe ao piloto por canal seguro)`);
          }
        } catch (err) {
          // se falhar ao copiar, só mostra
          alert(`Piloto ${formData.nome} salvo com sucesso!\nSenha temporária: ${tempPassword}\n(Copie e encaminhe ao piloto por canal seguro)`);
        }
        console.info("Senha temporária retornada pelo backend (DEBUG):", tempPassword);
      } else {
        alert(`Piloto ${formData.nome} salvo com sucesso!`);
      }

      // endereço (tenta PUT, se 404 tenta POST)
      const enderecoPayload = {
        cpf_piloto: formData.cpfPiloto,
        tipo_endereco: formData.tipoEndereco,
        cep: formData.cep,
        logradouro: formData.logradouro,
        numero: formData.numero ? (isNaN(Number(formData.numero)) ? null : Number(formData.numero)) : null,
        complemento: formData.complemento,
        bairro: formData.bairro,
        cidade: formData.cidade,
        uf: formData.uf,
        pais: formData.pais,
      };

      if (isUpdate) {
        try {
          await axios.put(`${API_URL}/endereco/${encodeURIComponent(formData.cpfPiloto)}`, enderecoPayload, { headers: { Authorization: `Bearer ${getToken()}` } });
        } catch (error) {
          if (error.response?.status === 404) {
            await axios.post(`${API_URL}/endereco/`, enderecoPayload, { headers: { Authorization: `Bearer ${getToken()}` } });
          } else {
            console.error("Erro ao atualizar endereço:", error);
          }
        }
      } else {
        try {
          await axios.post(`${API_URL}/endereco/${encodeURIComponent(formData.cpfPiloto)}`, enderecoPayload, { headers: { Authorization: `Bearer ${getToken()}`, "Content-Type": "application/json" } });
        } catch (err) {
          try {
            await axios.post(`${API_URL}/endereco`, enderecoPayload, { headers: { Authorization: `Bearer ${getToken()}`, "Content-Type": "application/json" } });
          } catch (e) {
            console.error("Erro ao criar endereço:", e);
          }
        }
      }

      // carro
      const carroPayload = {
        foto_frente: await fileToBase64(formData.fotoFrente),
        foto_tras: await fileToBase64(formData.fotoTras),
        foto_esquerda: await fileToBase64(formData.fotoEsquerda),
        foto_direita: await fileToBase64(formData.fotoDireita),
        nota_fiscal: await fileToBase64(formData.notaFiscal),
      };

      if (isUpdate) {
        try {
          await axios.put(`${API_URL}/carros/${encodeURIComponent(formData.cpfPiloto)}`, carroPayload, { headers: { Authorization: `Bearer ${getToken()}` } });
        } catch (error) {
          if (error.response?.status === 404) {
            await axios.post(`${API_URL}/carros/${encodeURIComponent(formData.cpfPiloto)}`, carroPayload, { headers: { Authorization: `Bearer ${getToken()}`, "Content-Type": "application/json" } });
          } else {
            console.error("Erro ao atualizar carros:", error);
          }
        }
      } else {
        try {
          await axios.post(`${API_URL}/carros/${encodeURIComponent(formData.cpfPiloto)}`, carroPayload, { headers: { Authorization: `Bearer ${getToken()}`, "Content-Type": "application/json" } });
        } catch (err) {
          console.error("Erro ao criar carro:", err);
        }
      }

      resetForm();
      navigate("/pilotos");
    } catch (error) {
      console.error("Erro ao salvar piloto:", error);
      if (error.response) console.debug("Server response:", error.response.data);
      if (error.response?.status === 409) {
        const serverMsg = error.response.data?.detail || error.response.data?.message || JSON.stringify(error.response.data) || "Conflito ao salvar: recurso já existe.";
        setLastSaveError(serverMsg);
        alert(`Erro (conflito): ${serverMsg}`);
      } else if (error.response?.status === 422) {
        const errors = error.response.data?.errors || {};
        const msg = Object.entries(errors).map(([f, m]) => `${f}: ${m.join?.(",") ?? m}`).join("\n");
        alert(`Erros de validação:\n${msg || "Dados inválidos"}`);
      } else {
        setLastSaveError(error.message);
        alert(`Erro: ${error.message}`);
      }
    } finally {
      setIsLoading(false);
    }
  };

  const handleBack = () => navigate("/pilotos", { replace: true });

  const formatDateToISO = (dateInput) => {
    try {
      if (!dateInput) return null;
      if (typeof dateInput === "string" && dateInput.match(/^\d{2}\/\d{2}\/\d{4}$/)) {
        const [d, m, y] = dateInput.split("/");
        return `${y}-${m}-${d}T00:00:00`;
      }
      if (typeof dateInput === "string" && dateInput.includes("T")) return dateInput;
      if (typeof dateInput === "string" && dateInput.match(/^\d{4}-\d{2}-\d{2}$/)) return `${dateInput}T00:00:00`;
      const date = new Date(dateInput);
      if (isNaN(date.getTime())) throw new Error("Data inválida");
      return date.toISOString().split("T")[0] + "T00:00:00";
    } catch (error) {
      console.error("Erro ao formatar data:", error);
      return null;
    }
  };

  const formatISOToDisplay = (isoDate) => {
    try {
      if (!isoDate) return "";
      const d = new Date(isoDate);
      if (!isNaN(d.getTime())) {
        const day = String(d.getDate()).padStart(2, "0");
        const month = String(d.getMonth() + 1).padStart(2, "0");
        const year = d.getFullYear();
        return `${day}/${month}/${year}`;
      }
      const match = isoDate.match(/^(\d{4})-(\d{2})-(\d{2})/);
      if (match) return `${match[3]}/${match[2]}/${match[1]}`;
      return isoDate;
    } catch (e) {
      return isoDate;
    }
  };

  const formatCepMask = (value) => {
    if (!value) return "";
    const digits = value.replace(/\D/g, "").slice(0, 8);
    if (digits.length <= 5) return digits;
    return `${digits.slice(0, 5)}-${digits.slice(5)}`;
  };
  const handleCepChange = (e) => {
    let value = e.target.value.replace(/\D/g, "");
    if (value.length > 8) value = value.slice(0, 8);
    setFormData((prev) => ({ ...prev, cep: value }));
  };
  const handleCepBlur = (e) => setFormData((prev) => ({ ...prev, cep: formatCepMask(e.target.value) }));

  const formatDateMask = (value) => {
    if (!value) return "";
    const digits = value.replace(/\D/g, "").slice(0, 8);
    const parts = [];
    if (digits.length >= 2) {
      parts.push(digits.slice(0, 2));
      if (digits.length >= 4) {
        parts.push(digits.slice(2, 4));
        if (digits.length > 4) parts.push(digits.slice(4));
      } else if (digits.length > 2) parts.push(digits.slice(2));
    } else parts.push(digits);
    return parts.join("/");
  };
  const handleDateChange = (e) => {
    const masked = formatDateMask(e.target.value);
    setFormData((prev) => ({ ...prev, dtNascimento: masked }));
  };

  return (
    <div className="min-h-screen bg-gray-100 p-4">
      {isLoading && <Loading message="Salvando..." />}

      <div className="max-w-2xl mx-auto bg-white rounded-lg shadow-lg overflow-hidden">
        <div className="bg-gray-800 p-4">
          <div className="flex justify-between items-center mb-2">
            <button onClick={() => handleBack()} className="bg-gray-600 hover:bg-gray-700 text-white px-3 py-1 rounded-md transition-colors duration-200 flex items-center">
              Voltar
            </button>
            <div className="text-center flex-1">
              <h1 className="text-white text-xl font-bold">{isUpdate ? "Editar Piloto" : "Cadastrar Piloto"}</h1>
            </div>
            <div className="w-20" />
          </div>
          <p className="text-blue-100 text-center">UTV LEGAL - Sistema de Gestão</p>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {/* Dados Pessoais */}
          <div className="border-b border-gray-200 pb-2">
            <button type="button" onClick={() => toggleDropdown("dadosPessoais")} className="flex justify-between items-center w-full text-left py-2 font-medium text-gray-800 focus:outline-none">
              <span className="text-lg font-semibold">Dados do Piloto</span>
              <svg className={`w-5 h-5 transition-transform duration-200 ${dropdownAberto.dadosPessoais ? "transform rotate-180" : ""}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
              </svg>
            </button>

            {dropdownAberto.dadosPessoais && (
              <div className="mt-4 space-y-4 pl-2 border-l-2 border-blue-200 ml-1">
                <div>
                  <label className="block text-sm font-medium text-gray-700">Nome Completo *</label>
                  <input type="text" name="nome" value={formData.nome} onChange={handleChange} required className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 p-2 border text-gray-900" />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700">CPF *</label>
                  <input type="text" name="cpfPiloto" value={formData.cpfPiloto} onChange={handleChange} required className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 p-2 border text-gray-900" disabled={isUpdate} />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Dt. Nascimento *</label>
                    <input type="text" name="dtNascimento" value={formData.dtNascimento} onChange={handleDateChange} placeholder="DD/MM/AAAA" className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 p-2 border text-gray-900" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Tipo Sanguíneo *</label>
                    <select name="tipoSanguineo" value={formData.tipoSanguineo ?? ""} onChange={handleChange} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 p-2 border text-gray-900">
                      <option value="">Selecione</option>
                      <option value="1">A+</option>
                      <option value="2">A-</option>
                      <option value="3">B+</option>
                      <option value="4">B-</option>
                      <option value="5">AB+</option>
                      <option value="6">AB-</option>
                      <option value="7">O+</option>
                      <option value="8">O-</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700">E-mail *</label>
                  <input type="email" name="email" value={formData.email} onChange={handleChange} required className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 p-2 border text-gray-900" />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700">Celular *</label>
                  <input type="tel" name="celular" value={formData.celular} onChange={handleChange} required className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 p-2 border text-gray-900" />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700">Estado Civil *</label>
                  <select name="estadoCivil" value={formData.estadoCivil ?? ""} onChange={handleChange} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 p-2 border text-gray-900">
                    <option value="">Selecione</option>
                    <option value="1">Solteiro(a)</option>
                    <option value="2">Casado(a)</option>
                    <option value="3">Viúvo(a)</option>
                    <option value="4">Outro(a)</option>
                  </select>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Contato de Emergência *</label>
                    <input type="text" name="contatoEmergencia" value={formData.contatoEmergencia} onChange={handleChange} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 p-2 border text-gray-900" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Telefone *</label>
                    <input type="tel" name="telefoneEmergencia" value={formData.telefoneEmergencia} onChange={handleChange} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 p-2 border text-gray-900" />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700">Plano de Saúde</label>
                  <input type="text" name="planoSaude" value={formData.planoSaude} onChange={handleChange} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 p-2 border text-gray-900" />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700">Foto do Piloto</label>
                  <input type="file" name="fotoPiloto" onChange={handleChange} className="mt-1 block w-full text-sm text-gray-500" accept="image/*" />
                  {formData.fotoPiloto && <p className="text-xs text-gray-500 mt-1">Arquivo: {formData.fotoPiloto.name}</p>}
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700">Foto Carteira de Motorista (PDF)</label>
                  <input type="file" name="fotoCarteira" onChange={handleChange} className="mt-1 block w-full text-sm text-gray-500" accept=".pdf" />
                  {formData.fotoCarteira && <p className="text-xs text-gray-500 mt-1">Arquivo: {formData.fotoCarteira.name}</p>}
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700">Termo de Adesão (PDF)</label>
                  <input type="file" name="termoAdesao" onChange={handleChange} className="mt-1 block w-full text-sm text-gray-500" accept=".pdf" />
                  {formData.termoAdesao && <p className="text-xs text-gray-500 mt-1">Arquivo: {formData.termoAdesao.name}</p>}
                </div>

                {/* Exibição somente leitura do ID do sistema quando for edição */}
                {isUpdate && (
                  <div>
                    <label className="block text-sm font-medium text-gray-700">ID do Piloto (gerado pelo sistema)</label>
                    <div className="mt-1 p-2 border rounded bg-gray-50 text-gray-700">{formData.idPiloto || "—"}</div>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Endereço */}
          <div className="border-b border-gray-200 pb-2">
            <button type="button" onClick={() => toggleDropdown("endereco")} className="flex justify-between items-center w-full text-left py-2 font-medium text-gray-800 focus:outline-none">
              <span className="text-lg font-semibold">Endereço</span>
              <svg className={`w-5 h-5 transition-transform duration-200 ${dropdownAberto.endereco ? "transform rotate-180" : ""}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
              </svg>
            </button>

            {dropdownAberto.endereco && (
              <div className="mt-4 space-y-4 pl-2 border-l-2 border-blue-200 ml-1">
                <div>
                  <label className="block text-sm font-medium text-gray-700">Tipo de Endereço</label>
                  <select name="tipoEndereco" value={formData.tipoEndereco} onChange={handleChange} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm p-2">
                    <option value="RESIDENCIAL">Residencial</option>
                    <option value="COMERCIAL">Comercial</option>
                    <option value="OUTRO">Outro</option>
                  </select>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700">CEP</label>
                    <input type="text" name="cep" value={formData.cep} onChange={handleCepChange} onBlur={handleCepBlur} placeholder="00000-000" maxLength={9} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm p-2" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Número</label>
                    <input type="text" name="numero" value={formData.numero} onChange={handleChange} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm p-2" />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700">Logradouro</label>
                  <input type="text" name="logradouro" value={formData.logradouro} onChange={handleChange} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm p-2" />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700">Complemento</label>
                  <input type="text" name="complemento" value={formData.complemento} onChange={handleChange} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm p-2" />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700">Bairro</label>
                  <input type="text" name="bairro" value={formData.bairro} onChange={handleChange} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm p-2" />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Cidade</label>
                    <input type="text" name="cidade" value={formData.cidade} onChange={handleChange} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm p-2" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700">UF</label>
                    <select name="uf" value={formData.uf} onChange={handleChange} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm p-2">
                      <option value="">Selecione</option>
                      {Object.entries(EstadosBrasileiros).map(([sigla, nome]) => (
                        <option key={sigla} value={sigla}>{nome} - {sigla}</option>
                      ))}
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700">País</label>
                  <input type="text" name="pais" value={formData.pais} onChange={handleChange} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm p-2" />
                </div>
              </div>
            )}
          </div>

          {/* Carro */}
          <div className="border-b border-gray-200 pb-2">
            <button type="button" onClick={() => toggleDropdown("carro")} className="flex justify-between items-center w-full text-left py-2 font-medium text-gray-800 focus:outline-none">
              <span className="text-lg font-semibold">Dados do Carro</span>
              <svg className={`w-5 h-5 transition-transform duration-200 ${dropdownAberto.carro ? "transform rotate-180" : ""}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
              </svg>
            </button>

            {dropdownAberto.carro && (
              <div className="mt-4 space-y-4 pl-2 border-l-2 border-blue-200 ml-1">
                <div>
                  <label className="block text-sm font-medium text-gray-700">Foto da Frente do Carro</label>
                  <input type="file" name="fotoFrente" onChange={handleChange} className="mt-1 block w-full text-sm text-gray-500" accept="image/*" />
                  {formData.fotoFrente && <p className="text-xs text-gray-500 mt-1">Arquivo: {formData.fotoFrente.name}</p>}
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700">Foto da Traseira do Carro</label>
                  <input type="file" name="fotoTras" onChange={handleChange} className="mt-1 block w-full text-sm text-gray-500" accept="image/*" />
                  {formData.fotoTras && <p className="text-xs text-gray-500 mt-1">Arquivo: {formData.fotoTras.name}</p>}
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700">Foto do Lado Esquerdo</label>
                  <input type="file" name="fotoEsquerda" onChange={handleChange} className="mt-1 block w-full text-sm text-gray-500" accept="image/*" />
                  {formData.fotoEsquerda && <p className="text-xs text-gray-500 mt-1">Arquivo: {formData.fotoEsquerda.name}</p>}
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700">Foto do Lado Direito</label>
                  <input type="file" name="fotoDireita" onChange={handleChange} className="mt-1 block w-full text-sm text-gray-500" accept="image/*" />
                  {formData.fotoDireita && <p className="text-xs text-gray-500 mt-1">Arquivo: {formData.fotoDireita.name}</p>}
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700">Nota Fiscal (PDF)</label>
                  <input type="file" name="notaFiscal" onChange={handleChange} className="mt-1 block w-full text-sm text-gray-500" accept=".pdf,.jpg,.jpeg,.png" />
                  {formData.notaFiscal && <p className="text-xs text-gray-500 mt-1">Arquivo: {formData.notaFiscal.name}</p>}
                </div>
              </div>
            )}
          </div>

          <div className="pt-4 flex space-x-4">
            <button type="button" onClick={resetForm} className="flex-1 bg-gray-500 hover:bg-gray-600 text-white font-bold py-3 px-4 rounded-md">Cancelar</button>
            <button type="submit" className="flex-1 bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-4 rounded-md">Salvar</button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default CadastroPiloto;
