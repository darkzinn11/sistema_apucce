// src/pages/Pilotos/ListaPilotos/index.jsx
import React, { useEffect, useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import Loading from "../../../components/Loading.jsx";
import { API_URL } from "../../../utils/apiUrl.js";
import { isAuthenticated, hasRole, getToken } from "../../../services/authService.js";

const authHeader = () => ({ Authorization: `Bearer ${getToken()}` });

export default function ListaPilotos() {
  const navigate = useNavigate();
  const [pilotos, setPilotos] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    if (!isAuthenticated() || !hasRole("ADMIN")) {
      navigate("/home");
      return;
    }
    loadPilotos();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const loadPilotos = async () => {
    setIsLoading(true);
    setError(null);
    try {
      const res = await axios.get(`${API_URL}/pilotos`, { headers: authHeader() });
      const data = Array.isArray(res.data) ? res.data : [];
      setPilotos(data);
    } catch (err) {
      console.error("Erro ao buscar pilotos:", err);
      setError("Não foi possível carregar a lista de pilotos.");
    } finally {
      setIsLoading(false);
    }
  };

  const handleCreate = () => {
    // rota que seu front usa (ajuste se necessário)
    navigate("/pilotos/cadastro");
  };

  const handleEdit = (cpf) => {
    if (!cpf) return;
    navigate(`/pilotos/cadastro?cpf=${encodeURIComponent(cpf)}`);
  };

  const handleView = (cpf) => {
    if (!cpf) return;
    // caso você tenha rota de detalhes, ajuste aqui; senão abre o form em modo leitura
    navigate(`/pilotos/cadastro?cpf=${encodeURIComponent(cpf)}`);
  };

  const handleDelete = async (cpf, nome) => {
    if (!cpf) return alert("CPF inválido");
    const ok = window.confirm(`Confirma remover o piloto ${nome} (CPF ${cpf}) ?`);
    if (!ok) return;
    setIsLoading(true);
    try {
      await axios.delete(`${API_URL}/pilotos/${encodeURIComponent(cpf)}`, { headers: authHeader() });
      // recarrega lista
      await loadPilotos();
      alert("Piloto removido com sucesso.");
    } catch (err) {
      console.error("Erro ao remover piloto:", err);
      const msg = err.response?.data?.message || err.message || "Erro ao remover";
      alert(`Erro ao remover: ${msg}`);
    } finally {
      setIsLoading(false);
    }
  };

  const renderRow = (p, index) => {
    const key = p.id ?? p.id_piloto ?? p.cpf_piloto ?? p.cpf ?? `piloto-${index}`;
    const nome = p.nome_piloto ?? p.nome ?? p.name ?? "—";
    const cpf = p.cpf_piloto ?? p.cpf ?? "—";
    const email = p.email_piloto ?? p.email ?? "—";

    return (
      <tr key={key} className="hover:bg-gray-50">
        <td className="py-3 px-4 align-top">{nome}</td>
        <td className="py-3 px-4 align-top">{cpf}</td>
        <td className="py-3 px-4 align-top">{email}</td>
        <td className="py-3 px-4 align-top">
          <div className="flex gap-2">
            <button onClick={() => handleView(cpf)} className="px-3 py-1 bg-gray-200 rounded hover:bg-gray-300">Ver</button>
            <button onClick={() => handleEdit(cpf)} className="px-3 py-1 bg-blue-600 text-white rounded hover:bg-blue-700">Editar</button>
            <button onClick={() => handleDelete(cpf, nome)} className="px-3 py-1 bg-red-600 text-white rounded hover:bg-red-700">Excluir</button>
          </div>
        </td>
      </tr>
    );
  };

  return (
    <div className="min-h-screen bg-gray-100 p-4">
      {isLoading && <Loading message="Carregando pilotos..." />}

      <div className="max-w-4xl mx-auto bg-white rounded-lg shadow overflow-hidden">
        <div className="bg-gray-800 p-4 flex items-center justify-between">
          <div>
            <h1 className="text-white text-xl font-bold">Lista de Pilotos</h1>
            <p className="text-gray-300 text-sm">Gerencie os pilotos cadastrados</p>
          </div>
          <div>
            <button onClick={handleCreate} className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">+ Novo Piloto</button>
          </div>
        </div>

        <div className="p-4">
          {error && <div className="text-red-600 mb-4">{error}</div>}

          <div className="overflow-x-auto">
            <table className="w-full table-auto">
              <thead className="text-left text-sm text-gray-600 border-b">
                <tr>
                  <th className="py-3 px-4">Nome</th>
                  <th className="py-3 px-4">CPF</th>
                  <th className="py-3 px-4">E-mail</th>
                  <th className="py-3 px-4">Ações</th>
                </tr>
              </thead>
              <tbody>
                {pilotos.length === 0 && !isLoading ? (
                  <tr>
                    <td colSpan="4" className="py-6 px-4 text-center text-gray-500">Nenhum piloto encontrado.</td>
                  </tr>
                ) : (
                  pilotos.map((p, i) => renderRow(p, i))
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}
