import { useNavigate, useSearchParams } from "react-router-dom";
import { useEffect, useState } from "react";
import Loading from "../../components/Loading";
import { getUserRole, isAuthenticated } from "../../services/authService";

const mapRole = (role) => {
  // backend -> frontend
  // admin   -> ADMIN   (acesso total)
  // gestor  -> FISCAL  (pode fiscalizar)
  // operador-> USER    (meus dados)
  if (!role) return null;
  const r = String(role).toLowerCase();
  if (r === "admin") return "ADMIN";
  if (r === "gestor") return "FISCAL";
  if (r === "operador") return "USER";
  // fallback: tenta manter compatibilidade se já vier em maiúsculo
  return role.toUpperCase();
};

const Home = () => {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const [isLoading, setIsLoading] = useState(false);
  const [userRole, setUserRole] = useState(null);

  const idPiloto = searchParams.get("idPiloto");

  useEffect(() => {
    // Se não autenticado, salva redirecionamento e volta pro login
    if (!isAuthenticated()) {
      if (idPiloto) {
        sessionStorage.setItem(
          "redirectAfterLogin",
          `/fiscalizacao?idPiloto=${idPiloto}`
        );
        sessionStorage.setItem("pendingPilotoId", idPiloto);
        alert("Usuário não autenticado");
      }
      navigate("/");
      return;
    }

    // Normaliza papel
    const role = mapRole(getUserRole());
    setUserRole(role);

    // Redirecionamento rápido para fiscalização via link compartilhado
    if (idPiloto) {
      setIsLoading(true);
      const timer = setTimeout(() => {
        navigate(`/fiscalizacao?idPiloto=${idPiloto}`);
      }, 500);
      return () => clearTimeout(timer);
    }
  }, [idPiloto, navigate]);

  const handleAdministracao = () => {
    if (userRole !== "ADMIN") {
      alert("Acesso restrito a administradores");
      return;
    }
    navigate("/pilotos");
  };

  const handleFiscalizacao = () => {
    if (userRole !== "ADMIN" && userRole !== "FISCAL") {
      alert("Acesso restrito a administradores e fiscais");
      return;
    }
    navigate("/fiscalizacao");
  };

  const handleUsuarios = () => {
    if (userRole !== "ADMIN") {
      alert("Acesso restrito a administradores");
      return;
    }
    navigate("/usuarios");
  };

  const handleMeusDados = () => {
    navigate("/meus-dados");
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-100 flex items-center justify-center">
        <Loading message="Redirecionando para fiscalização..." />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-100 flex items-center justify-center p-4">
      <div className="max-w-md w-full bg-white rounded-lg shadow-lg overflow-hidden">
        {/* Cabeçalho */}
        <div className="bg-gray-800 p-6 text-center">
          <h1 className="text-white text-3xl font-bold">UTV LEGAL</h1>
          <p className="text-blue-100 mt-2">Gestão de veículos de tração</p>
          <p className="text-blue-200 text-sm mt-1">Usuário: {userRole ?? "-"}</p>
        </div>

        {/* Conteúdo */}
        <div className="p-6">
          <div className="text-center mb-8">
            <h2 className="text-2xl font-semibold text-gray-800 mb-2">
              Sistema de Gestão
            </h2>
            <p className="text-gray-600">
              Selecione o módulo desejado para continuar
            </p>
          </div>

          <div className="space-y-4">
            {/* Administração - apenas ADMIN */}
            {userRole === "ADMIN" && (
              <button
                onClick={handleAdministracao}
                className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-4 px-6 rounded-lg transition duration-200 flex items-center justify-center"
              >
                {/* ícone */}
                <svg className="w-6 h-6 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
                        d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"/>
                </svg>
                Pilotos
              </button>
            )}

            {/* Fiscalização - ADMIN e FISCAL */}
            {(userRole === "ADMIN" || userRole === "FISCAL") && (
              <button
                onClick={handleFiscalizacao}
                className="w-full bg-green-600 hover:bg-green-700 text-white font-bold py-4 px-6 rounded-lg transition duration-200 flex items-center justify-center"
              >
                <svg className="w-6 h-6 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
                        d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"/>
                </svg>
                Fiscalizar
              </button>
            )}

            {/* Usuários - apenas ADMIN */}
            {userRole === "ADMIN" && (
              <button
                onClick={handleUsuarios}
                className="w-full bg-purple-600 hover:bg-purple-700 text-white font-bold py-4 px-6 rounded-lg transition duration-200 flex items-center justify-center"
              >
                <svg className="w-6 h-6 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
                        d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"/>
                </svg>
                Usuários
              </button>
            )}

            {/* Meus Dados - USER */}
            {userRole === "USER" && (
              <button
                onClick={handleMeusDados}
                className="w-full bg-orange-600 hover:bg-orange-700 text-white font-bold py-4 px-6 rounded-lg transition duration-200 flex items-center justify-center"
              >
                <svg className="w-6 h-6 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
                        d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"/>
                </svg>
                Meus Dados
              </button>
            )}
          </div>

          {/* Rodapé */}
          <div className="mt-8 text-center">
            <p className="text-sm text-gray-500">
              Sistema desenvolvido para gestão de veículos de tração
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Home;
