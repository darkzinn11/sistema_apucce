import axios from "axios";
import { useState, useEffect } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import Loading from "../../components/Loading";
import { API_URL } from "../../utils/apiUrl.js";
import {
  getUserRole,
  getToken,
  isAuthenticated,
} from "../../services/authService";

const arrayBufferToBase64 = (buffer) => {
  if (!buffer) return "";

  if (typeof buffer === "string") {
    return buffer;
  }

  let binary = "";
  const bytes = new Uint8Array(buffer);
  const len = bytes.byteLength;

  for (let i = 0; i < len; i++) {
    binary += String.fromCharCode(bytes[i]);
  }

  return window.btoa(binary);
};

const Fiscalizacao = () => {
  const [idPiloto, setIdPiloto] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState("");
  const [piloto, setPiloto] = useState(null);
  const [carro, setCarro] = useState(null);
  const [showModal, setShowModal] = useState(false);
  const [searchParams] = useSearchParams();

  const idPilotoParam = searchParams.get("idPiloto");
  const navigate = useNavigate();

  useEffect(() => {
    console.debug("Entrou no useEffect");
    if (!isAuthenticated()) {
      if (idPilotoParam) {
        sessionStorage.setItem(
          "redirectAfterLogin",
          `/fiscalizacao?idPiloto=${idPilotoParam}`
        );
        sessionStorage.setItem("pendingPilotoId", idPilotoParam);
      }
      alert("Acesso restrito a administradores e Fiscais");
      navigate("/");
      return;
    }

    const role = getUserRole();
    if (role !== "ADMIN" && role !== "FISCAL") {
      navigate("/home");
    }

    // Se houver um ID de piloto na URL e o usuário estiver autenticado
    if (idPilotoParam) {
      setIdPiloto(idPilotoParam);
      // Buscar automaticamente o piloto
      buscarPilotoPorId(idPilotoParam);
    }
  }, [idPilotoParam, navigate]);

  const bloodType = (bloodCode) => {
    switch (bloodCode) {
      case 1:
        return "A positivo";
      case 2:
        return "A negativo";
      case 3:
        return "B positivo";
      case 4:
        return "B negativo";
      case 5:
        return "AB positivo";
      case 6:
        return "AB negativo";
      case 7:
        return "O positivo";
      case 8:
        return "O negativo";
      default:
        return "Tipo sanguíneo desconhecido";
    }
  };

  const estadoCivil = (codigoEstadoCivil) => {
    switch (codigoEstadoCivil) {
      case 1:
        return "Solteiro";
      case 2:
        return "Casado";
      case 3:
        return "Viúvo";
      case 4:
        return "Outros";
      default:
        return "Estado civil desconhecido";
    }
  };

  const renderImagemCarro = (
    imagemBase64,
    alt,
    className = "w-full h-48 object-cover rounded"
  ) => {
    if (!imagemBase64) {
      return (
        <div className="h-48 bg-gray-200 rounded flex items-center justify-center">
          <span className="text-gray-500">Imagem não disponível</span>
        </div>
      );
    }

    return (
      <img
        src={`data:image/jpeg;base64,${arrayBufferToBase64(imagemBase64)}`}
        alt={alt}
        className={className}
        onError={(e) => {
          console.error("Erro ao carregar imagem do carro:", e);
          e.target.onerror = null;
          e.target.src = "/placeholder-car.jpg";
        }}
      />
    );
  };

  const renderFotoPiloto = (piloto) => {
    if (!piloto.foto_piloto) {
      return (
        <div className="w-32 h-32 rounded-full bg-gray-200 flex items-center justify-center">
          <span className="text-gray-500">Sem foto</span>
        </div>
      );
    }

    try {
      const base64String = arrayBufferToBase64(piloto.foto_piloto);

      return (
        <img
          src={`data:${
            piloto.foto_piloto_tipo || "image/jpeg"
          };base64,${base64String}`}
          alt={`Foto de ${piloto.nome_piloto}`}
          className="w-32 h-32 rounded-full object-cover border-4 border-gray-200"
          onError={(e) => {
            console.error("Erro ao carregar imagem:", e);
            e.target.onerror = null;
            e.target.src = "/placeholder-user.jpg";
          }}
        />
      );
    } catch (error) {
      console.error("Erro ao converter imagem:", error);
      return (
        <div className="w-32 h-32 rounded-full bg-gray-200 flex items-center justify-center">
          <span className="text-gray-500">Erro na foto</span>
        </div>
      );
    }
  };

  const renderFotoCNH = (
    cnhBase64,
    fileType,
    className = "w-full h-64 bg-gray-100 rounded-lg"
  ) => {
    if (!cnhBase64) {
      return (
        <div className={className}>
          <div className="flex items-center justify-center h-full">
            <span className="text-gray-500">CNH não disponível</span>
          </div>
        </div>
      );
    }

    // Se for PDF
    if (fileType === "application/pdf") {
      return (
        <div className={className}>
          <div className="flex flex-col items-center justify-center h-full p-4">
            <div className="mb-4">
              <svg
                className="w-16 h-16 text-gray-400"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M7 21h10a2 2 0 002-2V9.414a1 1 0 00-.293-.707l-5.414-5.414A1 1 0 0012.586 3H7a2 2 0 00-2 2v14a2 2 0 002 2z"
                />
              </svg>
            </div>
            <span className="text-gray-700 mb-4">CNH (PDF)</span>
            <button
              onClick={() => {
                const pdfData = `data:application/pdf;base64,${arrayBufferToBase64(
                  cnhBase64
                )}`;
                window.open(pdfData, "_blank");
              }}
              className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded text-sm"
            >
              Visualizar PDF
            </button>
          </div>
        </div>
      );
    }

    // Se for imagem
    return (
      <div className={className}>
        <img
          src={`data:${fileType || "image/jpeg"};base64,${arrayBufferToBase64(
            cnhBase64
          )}`}
          alt="CNH do piloto"
          className="w-full h-full object-contain rounded-lg"
          onError={(e) => {
            console.error("Erro ao carregar CNH:", e);
            e.target.onerror = null;
            e.target.src = "/placeholder-doc.jpg";
          }}
        />
      </div>
    );
  };

  const renderTermoAdesao = (
    termoBase64,
    className = "bg-gray-100 p-4 rounded-lg"
  ) => {
    if (!termoBase64) {
      return (
        <div className={className}>
          <div className="flex items-center justify-center">
            <span className="text-gray-500">
              Termo de adesão não disponível
            </span>
          </div>
        </div>
      );
    }

    return (
      <div className={className}>
        <div className="flex items-center justify-between">
          <span className="text-gray-700">Termo de Adesão (PDF)</span>
          <button
            onClick={() => {
              const pdfData = `data:application/pdf;base64,${arrayBufferToBase64(
                termoBase64
              )}`;
              window.open(pdfData, "_blank");
            }}
            className="bg-blue-600 hover:bg-blue-700 text-white px-3 py-1 rounded text-sm"
          >
            Visualizar PDF
          </button>
        </div>
      </div>
    );
  };

  const buscarPilotoPorId = async (id) => {
    console.debug("Buscando piloto por ID:", id);
    if (!id || !id.trim()) {
      setError("ID do piloto inválido");
      return;
    }

    setIsLoading(true);
    setError("");
    setPiloto(null);
    setCarro(null);

    try {
      const response = await axios.get(`${API_URL}/pilotos/fiscalizar/${id}`, {
        headers: {
          Authorization: `Bearer ${getToken()}`,
        },
      });
      const pilotoData = response.data;
      setPiloto(pilotoData);

      // Buscar carro do piloto
      try {
        const carroResponse = await axios.get(
          `${API_URL}/carros/${pilotoData.cpf_piloto}`,
          {
            headers: {
              Authorization: `Bearer ${getToken()}`,
            },
          }
        );
        setCarro(carroResponse.data);
      } catch (carroError) {
        console.error("Erro ao buscar carro:", carroError);
        setCarro(null);
      }

      setShowModal(true);
    } catch (error) {
      console.error("Erro ao buscar piloto:", error);
      if (error.response?.status === 404) {
        setError("Piloto não encontrado");
      } else {
        setError("Erro ao buscar piloto. Tente novamente.");
      }
    } finally {
      setIsLoading(false);
    }
  };

  const buscarPiloto = async (e) => {
    e.preventDefault();
    if (!idPiloto.trim()) {
      setError("Por favor, informe o ID do piloto");
      return;
    }

    setIsLoading(true);
    setError("");
    setPiloto(null);
    setCarro(null);

    try {
      // Buscar piloto
      const response = await axios.get(
        `${API_URL}/pilotos/fiscalizar/${idPiloto}`,
        {
          headers: {
            Authorization: `Bearer ${getToken()}`,
          },
        }
      );
      const pilotoData = response.data;

      setPiloto(pilotoData);

      // Buscar carro do piloto
      try {
        const carroResponse = await axios.get(
          `${API_URL}/carros/${pilotoData.cpf_piloto}`,
          {
            headers: {
              Authorization: `Bearer ${getToken()}`,
            },
          }
        );
        setCarro(carroResponse.data);
      } catch (carroError) {
        console.error("Erro ao buscar carro:", carroError);
        setCarro(null);
      }

      setShowModal(true);
    } catch (error) {
      console.error("Erro ao buscar piloto:", error);
      if (error.response?.status === 404) {
        setError("Piloto não encontrado");
      } else {
        setError("Erro ao buscar piloto. Tente novamente.");
      }
    } finally {
      setIsLoading(false);
    }
  };

  const fecharModal = () => {
    setShowModal(false);
    setPiloto(null);
    setCarro(null);
  };

  const handleVoltar = () => {
    navigate("/home");
  };

  return (
    <div className="min-h-screen bg-gray-100 p-4">
      {isLoading && <Loading message="Buscando piloto..." />}

      <div className="max-w-md mx-auto bg-white rounded-lg shadow-md overflow-hidden">
        {/* Cabeçalho */}
        <div className="bg-gray-800 p-4">
          <div className="flex justify-between items-start">
            <div>
              <h1 className="text-white text-2xl font-bold">UTV LEGAL</h1>
              <p className="text-blue-100">Módulo de Fiscalização</p>
            </div>
            <button
              onClick={handleVoltar}
              className="bg-gray-600 hover:bg-gray-700 text-white px-4 py-2 rounded-md transition-colors duration-200 ml-4"
            >
              Voltar
            </button>
          </div>
        </div>

        {/* Formulário de busca */}
        <div className="p-6">
          <div className="text-center mb-6">
            <h2 className="text-xl font-semibold text-gray-800 mb-2">
              Fiscalização de Pilotos
            </h2>
            <p className="text-gray-600">
              Digite o ID do piloto para verificar os documentos
            </p>
          </div>

          <form onSubmit={buscarPiloto} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                ID do Piloto *
              </label>
              <input
                type="text"
                value={idPiloto}
                onChange={(e) => setIdPiloto(e.target.value)}
                placeholder="Digite o ID do piloto"
                className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                required
              />
            </div>

            {error && (
              <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded">
                {error}
              </div>
            )}

            <button
              type="submit"
              disabled={isLoading}
              className="w-full bg-blue-600 hover:bg-blue-700 disabled:bg-blue-400 text-white font-bold py-3 px-4 rounded-md transition duration-200"
            >
              {isLoading ? "Buscando..." : "Buscar Piloto"}
            </button>
          </form>
        </div>
      </div>

      {/* Modal de resultados */}
      {showModal && piloto && (
        <div className="fixed inset-0 backdrop-blur-sm bg-black/30 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg shadow-lg w-full max-w-2xl max-h-[90vh] overflow-y-auto">
            <div className="bg-gray-800 p-4 sticky top-0 flex justify-between items-center">
              <h3 className="text-white text-xl font-bold">
                Dados do Piloto - {piloto.id_piloto}
              </h3>
              <button
                onClick={fecharModal}
                className="bg-gray-600 hover:bg-gray-700 text-white px-4 py-2 rounded-md"
              >
                Fechar
              </button>
            </div>

            <div className="p-6 space-y-6">
              {/* Foto do Piloto e CNH */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h4 className="text-lg font-semibold text-gray-800 mb-4 text-center">
                    Foto do Piloto
                  </h4>
                  <div className="flex justify-center">
                    {renderFotoPiloto(piloto)}
                  </div>
                </div>

                <div>
                  <h4 className="text-lg font-semibold text-gray-800 mb-4 text-center">
                    Carteira de Motorista (CNH)
                  </h4>
                  {renderFotoCNH(piloto.foto_cnh, piloto.foto_cnh_tipo)}
                </div>
              </div>

              {/* Informações do Piloto */}
              <div className="bg-gray-50 p-4 rounded-lg">
                <h4 className="text-lg font-semibold text-gray-800 mb-4">
                  Informações Pessoais
                </h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-500">
                      Nome Completo
                    </label>
                    <p className="mt-1 text-gray-900 font-medium">
                      {piloto.nome_piloto}
                    </p>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-500">
                      CPF
                    </label>
                    <p className="mt-1 text-gray-900">{piloto.cpf_piloto}</p>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-500">
                      Tipo Sanguíneo
                    </label>
                    <p className="mt-1 text-gray-900">
                      {bloodType(piloto.tipo_sanguineo)}
                    </p>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-500">
                      Estado Civil
                    </label>
                    <p className="mt-1 text-gray-900">
                      {estadoCivil(piloto.estado_civil)}
                    </p>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-500">
                      E-mail
                    </label>
                    <p className="mt-1 text-gray-900">{piloto.email_piloto}</p>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-500">
                      Celular
                    </label>
                    <p className="mt-1 text-gray-900">
                      {piloto.numero_telefone}
                    </p>
                  </div>
                </div>
              </div>

              {/* Contato de Emergência */}
              <div className="bg-gray-50 p-4 rounded-lg">
                <h4 className="text-lg font-semibold text-gray-800 mb-4">
                  Contato de Emergência
                </h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-500">
                      Nome do Contato
                    </label>
                    <p className="mt-1 text-gray-900 font-medium">
                      {piloto.nome_contato_seguranca || "Não informado"}
                    </p>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-500">
                      Telefone do Contato
                    </label>
                    <p className="mt-1 text-gray-900">
                      {piloto.numero_contato_seguranca || "Não informado"}
                    </p>
                  </div>
                </div>
              </div>

              {/* Termo de Adesão */}
              {piloto.termo_adesao && (
                <div className="bg-gray-50 p-4 rounded-lg">
                  <h4 className="text-lg font-semibold">Termo de Adesão</h4>
                  <div className="mt-4">
                    {renderTermoAdesao(piloto.termo_adesao)}
                  </div>
                </div>
              )}

              {/* Informações do Veículo */}
              {carro && (
                <div className="bg-gray-50 p-4 rounded-lg">
                  <h4 className="text-lg font-semibold text-gray-800 mb-4">
                    Veículo do Piloto
                  </h4>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-500 mb-2">
                        Frente do Veículo
                      </label>
                      {renderImagemCarro(
                        carro.foto_frente,
                        "Frente do veículo"
                      )}
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-500 mb-2">
                        Traseira do Veículo
                      </label>
                      {renderImagemCarro(
                        carro.foto_tras,
                        "Traseira do veículo"
                      )}
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-500 mb-2">
                        Lado Esquerdo
                      </label>
                      {renderImagemCarro(
                        carro.foto_esquerda,
                        "Lado esquerdo do veículo"
                      )}
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-500 mb-2">
                        Lado Direito
                      </label>
                      {renderImagemCarro(
                        carro.foto_direita,
                        "Lado direito do veículo"
                      )}
                    </div>
                  </div>

                  {carro.nota_fiscal && (
                    <div>
                      <label className="block text-sm font-medium text-gray-500 mb-2">
                        Nota Fiscal
                      </label>
                      <div className="bg-gray-100 p-4 rounded-lg">
                        <div className="flex items-center justify-between">
                          <span className="text-gray-700">
                            Documento disponível
                          </span>
                          <button
                            onClick={() => {
                              const pdfData = `data:application/pdf;base64,${arrayBufferToBase64(
                                carro.nota_fiscal
                              )}`;
                              window.open(pdfData, "_blank");
                            }}
                            className="bg-blue-600 hover:bg-blue-700 text-white px-3 py-1 rounded text-sm"
                          >
                            Visualizar PDF
                          </button>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              )}

              {!carro && (
                <div className="bg-yellow-100 border border-yellow-400 text-yellow-700 px-4 py-3 rounded">
                  Nenhum veículo cadastrado para este piloto
                </div>
              )}

              <div className="flex justify-center">
                <button
                  onClick={fecharModal}
                  className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-6 rounded-md transition duration-200"
                >
                  Fechar
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Fiscalizacao;
