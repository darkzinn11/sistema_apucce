// src/pages/Usuarios/ListaUsuarios.jsx
import axios from "axios";
import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { LoadingSpinner } from "../../../components/LoadingSpinner.jsx";
import { API_URL } from "../../../utils/apiUrl.js";
import { getUserRole, getToken } from "../../../services/authService.js";

const ListaUsuarios = () => {
  const [usuarios, setUsuarios] = useState([]); // sempre array
  const [isLoading, setIsLoading] = useState(false);
  const [isLoadingModal, setIsLoadingModal] = useState(false);
  const [usuarioSelecionado, setUsuarioSelecionado] = useState(null);
  const [showModal, setShowModal] = useState(false);

  const navigate = useNavigate();

  // tenta extrair lista de vários formatos possíveis
  const parseUsersResponse = (data) => {
    if (!data) return [];
    if (Array.isArray(data)) return data;
    if (Array.isArray(data.usuarios)) return data.usuarios;
    if (Array.isArray(data.data)) return data.data;
    if (Array.isArray(data.results)) return data.results;
    // se for um único objeto usuário
    if (typeof data === "object" && (data.email || data.nome || data.id)) return [data];
    return [];
  };

  // normaliza nome dos campos pra facilitar uso no front
  const normalizeUser = (u = {}) => {
    // possíveis nomes de campo para cada coisa
    const id = u.id ?? u.user_id ?? u.usuario_id ?? u.usuarioId ?? u._id ?? null;
    const email = u.email ?? u.email_usuario ?? u.username ?? u.user_email ?? null;
    const nome = u.nome ?? u.name ?? u.fullname ?? null;
    const tipo_usuario = u.tipo_usuario ?? u.tipoUsuario ?? u.tipo ?? u.role ?? u.permission ?? null;
    const is_active = typeof u.is_active !== "undefined" ? u.is_active : (typeof u.active !== "undefined" ? u.active : (typeof u.ativo !== "undefined" ? u.ativo : true));
    // data_atualizacao pode vir com vários nomes
    const data_atualizacao = u.data_atualizacao ?? u.updated_at ?? u.updatedAt ?? u.atualizado_em ?? null;

    return {
      ...u,
      id,
      email,
      nome,
      tipo_usuario,
      is_active,
      data_atualizacao,
    };
  };

  const getUsuarios = async () => {
    setIsLoading(true);
    try {
      const response = await axios.get(`${API_URL}/usuarios/`, {
        headers: {
          Authorization: `Bearer ${getToken()}`,
        },
      });

      const parsed = parseUsersResponse(response.data).map(normalizeUser);
      setUsuarios(parsed);
    } catch (error) {
      console.error("Erro ao buscar usuários:", error);
      alert("Erro ao carregar lista de usuários");
      setUsuarios([]); // garantir array para não quebrar o render
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    const role = getUserRole();

    // Se não for ADMIN, redirecionar
    if (role !== "ADMIN") {
      alert("Acesso restrito a administradores");
      navigate("/home");
      return;
    }

    getUsuarios();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const tipoUsuario = (tipo) => {
    if (!tipo) return "—";
    const t = String(tipo).toLowerCase();
    if (["admin", "administrator", "administrador", "gestor"].includes(t)) return "Administrador";
    if (["fiscal", "inspector", "inspecionar"].includes(t)) return "Fiscal";
    if (["user", "usuario", "usuário", "operador", "operator"].includes(t)) return "Usuário Comum";
    return tipo || "—";
  };

  const abrirModal = (usuario) => {
    setUsuarioSelecionado(normalizeUser(usuario));
    setShowModal(true);
  };

  const fecharModal = () => {
    setShowModal(false);
    setUsuarioSelecionado(null);
  };

  // deleção: usa id quando disponível, senão email
  const handleExcluir = async (emailOrUsuario) => {
    // aceitamos tanto string email quanto objeto usuário
    let email = null;
    let id = null;

    if (typeof emailOrUsuario === "string") {
      email = emailOrUsuario;
    } else if (typeof emailOrUsuario === "object" && emailOrUsuario !== null) {
      const nu = normalizeUser(emailOrUsuario);
      id = nu.id;
      email = nu.email;
    }

    if (!id && !email) {
      alert("Identificador inválido para exclusão.");
      return;
    }

    const conf = window.confirm("Tem certeza que deseja excluir este usuário?");
    if (!conf) return;

    setIsLoading(true);
    try {
      // preferir ID se presente (rota pode esperar id)
      const target = id ? `${API_URL}/usuarios/${encodeURIComponent(id)}` : `${API_URL}/usuarios/${encodeURIComponent(email)}`;
      await axios.delete(target, {
        headers: {
          Authorization: `Bearer ${getToken()}`,
        },
      });
      alert("Usuário excluído com sucesso!");
      await getUsuarios(); // Recarregar a lista
    } catch (error) {
      console.error("Erro ao excluir usuário:", error);
      if (error.response?.status === 404) {
        alert("Usuário não encontrado (já removido?).");
        await getUsuarios();
      } else if (error.response?.data?.detail) {
        alert(`Erro: ${error.response.data.detail}`);
      } else {
        alert("Erro ao excluir usuário");
      }
    } finally {
      setIsLoading(false);
      fecharModal();
    }
  };

  // edição: navega para a tela de cadastro com id e email (se possível)
  const handleEditar = (usuario) => {
    // usuario pode ser string email ou objeto
    if (!usuario) {
      alert("Email inválido para edição.");
      return;
    }

    let id = null;
    let email = null;
    if (typeof usuario === "string") {
      email = usuario;
    } else if (typeof usuario === "object") {
      const nu = normalizeUser(usuario);
      id = nu.id;
      email = nu.email;
    }

    // passamos ambos, o componente de edição pode escolher (id tem prioridade)
    const params = new URLSearchParams();
    if (id) params.set("id", id);
    if (email) params.set("email", email);

    navigate(`/usuarios/cadastro-usuarios?${params.toString()}`);
  };

  const handleCadastrarUsuario = () => {
    navigate("/usuarios/cadastro-usuarios");
  };

  const handleVoltar = () => {
    navigate("/home");
  };

  return (
    <div className="min-h-screen bg-gray-100 p-4">
      {isLoading && <LoadingSpinner message="Carregando..." />}
      {isLoadingModal && <LoadingSpinner message="Carregando dados do usuário..." />}

      <div className="max-w-md mx-auto bg-white rounded-lg shadow-md overflow-hidden">
        {/* Cabeçalho */}
        <div className="bg-gray-800 p-4">
          <div className="flex justify-between items-start mb-2">
            <div>
              <h1 className="text-white text-2xl font-bold">UTV LEGAL</h1>
              <p className="text-blue-100">Gestão de veículos de tração</p>
            </div>
            <button
              onClick={handleVoltar}
              className="bg-gray-600 hover:bg-gray-700 text-white px-4 py-2 rounded-md transition-colors duration-200 whitespace-nowrap"
            >
              Voltar
            </button>
          </div>
          <h2 className="text-white text-xl">Lista de Usuários</h2>
        </div>

        {/* Lista de usuários */}
        <div className="p-4">
          {(!usuarios || usuarios.length === 0) ? (
            <div className="text-center py-8">
              <p className="text-gray-500">Nenhum usuário cadastrado</p>
            </div>
          ) : (
            usuarios.map((usuario, idx) => {
              const u = normalizeUser(usuario);
              const key = u.id ?? u.email ?? `usuario-${idx}`;
              return (
                <div
                  key={key}
                  className="border-b border-gray-200 py-3 px-2 hover:bg-gray-50 cursor-pointer"
                  onClick={() => abrirModal(u)}
                >
                  <div className="flex justify-between items-center">
                    <div>
                      <h3 className="text-lg font-medium text-gray-800">
                        {u.email ?? u.nome ?? "—"}
                      </h3>
                      <p className="text-sm text-gray-600">
                        {tipoUsuario(u.tipo_usuario)}
                      </p>
                    </div>
                    <div className="flex space-x-2">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleEditar(u);
                        }}
                        className="bg-blue-600 hover:bg-blue-700 text-white p-1 rounded-md transition-colors"
                        title="Editar"
                        disabled={isLoading}
                      >
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor">
                          <path d="M13.586 3.586a2 2 0 112.828 2.828l-.793.793-2.828-2.828.793-.793zM11.379 5.793L3 14.172V17h2.828l8.38-8.379-2.83-2.828z" />
                        </svg>
                      </button>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleExcluir(u);
                        }}
                        className="bg-red-600 hover:bg-red-700 text-white p-1 rounded-md transition-colors"
                        title="Excluir"
                        disabled={isLoading}
                      >
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor">
                          <path fillRule="evenodd" d="M9 2a1 1 0 00-.894.553L7.382 4H4a1 1 0 000 2v10a2 2 0 002 2h8a2 2 0 002-2V6a1 1 0 100-2h-3.382l-.724-1.447A1 1 0 0011 2H9zM7 8a1 1 0 012 0v6a1 1 0 11-2 0V8zm5-1a1 1 0 00-1 1v6a1 1 0 102 0V8a1 1 0 00-1-1z" clipRule="evenodd" />
                        </svg>
                      </button>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Modal de detalhes do usuário */}
        {showModal && usuarioSelecionado && (
          <div className="fixed inset-0 backdrop-blur-sm bg-black/30 flex items-center justify-center p-4 z-50">
            <div className="bg-white rounded-lg shadow-lg w-full max-w-md max-h-[90vh] overflow-y-auto">
              <div className="bg-gray-800 p-4 sticky top-0 flex justify-between items-center">
                <h3 className="text-white text-xl font-bold">Detalhes do Usuário</h3>
                <div className="flex gap-1">
                  <button
                    onClick={() => handleEditar(usuarioSelecionado)}
                    className="bg-green-600 hover:bg-green-700 text-white p-2 rounded-md transition-colors"
                  >
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                      <path d="M13.586 3.586a2 2 0 112.828 2.828l-.793.793-2.828-2.828.793-.793zM11.379 5.793L3 14.172V17h2.828l8.38-8.379-2.83-2.828z" />
                    </svg>
                  </button>
                  <button
                    onClick={() => handleExcluir(usuarioSelecionado)}
                    className="bg-red-600 hover:bg-red-700 text-white p-2 rounded-md transition-colors"
                  >
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                      <path fillRule="evenodd" d="M9 2a1 1 0 00-.894.553L7.382 4H4a1 1 0 000 2v10a2 2 0 002 2h8a2 2 0 002-2V6a1 1 0 100-2h-3.382l-.724-1.447A1 1 0 0011 2H9zM7 8a1 1 0 012 0v6a1 1 0 11-2 0V8zm5-1a1 1 0 00-1 1v6a1 1 0 102 0V8a1 1 0 00-1-1z" clipRule="evenodd" />
                    </svg>
                  </button>
                </div>
              </div>

              <div className="p-4 space-y-4">
                <div className="flex justify-center">
                  <div className="w-32 h-32 rounded-full bg-blue-100 flex items-center justify-center">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                    </svg>
                  </div>
                </div>

                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-500">Email</label>
                    <p className="mt-1 text-gray-900">{usuarioSelecionado.email ?? "—"}</p>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-500">Tipo de Usuário</label>
                    <p className="mt-1 text-gray-900">{tipoUsuario(usuarioSelecionado.tipo_usuario)}</p>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-500">Status</label>
                    <p className="mt-1 text-gray-900">{usuarioSelecionado.is_active ? "Ativo" : "Inativo"}</p>
                  </div>

                  {usuarioSelecionado.data_atualizacao && (
                    <div>
                      <label className="block text-sm font-medium text-gray-500">Última Atualização</label>
                      <p className="mt-1 text-gray-900">{new Date(usuarioSelecionado.data_atualizacao).toLocaleDateString("pt-BR")}</p>
                    </div>
                  )}
                </div>

                <div className="pt-4">
                  <button onClick={fecharModal} className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-4 rounded-md transition duration-200">Fechar</button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Botão flutuante para cadastrar novo usuário */}
      <button onClick={handleCadastrarUsuario} className="fixed bottom-6 right-6 bg-blue-600 text-white p-4 rounded-full shadow-lg hover:bg-blue-700 transition">
        <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
        </svg>
      </button>
    </div>
  );
};

export default ListaUsuarios;
