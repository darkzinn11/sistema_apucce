// src/pages/Usuarios/CriarUsuario.jsx
import { useState, useEffect } from "react";
import axios from "axios";
import { useNavigate, useSearchParams } from "react-router-dom";
import { LoadingSpinner } from "../../../components/LoadingSpinner.jsx";
import { API_URL } from "../../../utils/apiUrl.js";
import { getUserRole, getToken } from "../../../services/authService.js";

const CriarUsuario = () => {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const emailQuery = searchParams.get("email");

  const [isLoading, setIsLoading] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState({
    nome: "",
    email: "",
    tipo_usuario: "ADMIN",
    senha: "",
    confirmarSenha: "",
  });
  const [errors, setErrors] = useState({});
  const [serverError, setServerError] = useState("");
  const [serverResponseDebug, setServerResponseDebug] = useState(null); // mostra response.data bruto

  useEffect(() => {
    const role = getUserRole();
    if (role !== "ADMIN") {
      alert("Acesso restrito a administradores");
      navigate("/home");
      return;
    }
  }, [navigate]);

  useEffect(() => {
    if (emailQuery) {
      setIsEditing(true);
      carregarUsuario(emailQuery);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [emailQuery]);

  const carregarUsuario = async (email) => {
    setIsLoading(true);
    setServerResponseDebug(null);
    try {
      const response = await axios.get(`${API_URL}/usuarios/${encodeURIComponent(email)}`, {
        headers: { Authorization: `Bearer ${getToken()}` },
      });
      const usuario = response.data || {};
      setFormData({
        nome: usuario.nome ?? usuario.name ?? "",
        email: usuario.email ?? usuario.email_usuario ?? "",
        tipo_usuario: usuario.tipo_usuario ?? usuario.tipoUsuario ?? "ADMIN",
        senha: "",
        confirmarSenha: "",
      });
    } catch (error) {
      console.error("Erro ao carregar usuário:", error);
      alert("Erro ao carregar usuário");
      navigate("/usuarios");
    } finally {
      setIsLoading(false);
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    if (errors[name]) setErrors((prev) => ({ ...prev, [name]: "" }));
    if (serverError) setServerError("");
    if (serverResponseDebug) setServerResponseDebug(null);
  };

  const validateForm = () => {
    const newErrors = {};
    if (!formData.nome || !formData.nome.trim()) {
      newErrors.nome = "Nome é obrigatório";
    }
    if (!formData.email || !formData.email.trim()) {
      newErrors.email = "Email é obrigatório";
    } else if (!/\S+@\S+\.\S+/.test(formData.email.trim())) {
      newErrors.email = "Email inválido";
    }

    if (!isEditing) {
      if (!formData.senha) newErrors.senha = "Senha é obrigatória";
      else if (formData.senha.length < 6) newErrors.senha = "Senha deve ter pelo menos 6 caracteres";
      if (formData.senha !== formData.confirmarSenha) newErrors.confirmarSenha = "As senhas não coincidem";
    } else {
      if (formData.senha && formData.senha.length < 6) newErrors.senha = "Senha deve ter pelo menos 6 caracteres";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setServerError("");
    setErrors({});
    setServerResponseDebug(null);

    if (!validateForm()) return;

    setIsLoading(true);
    try {
      // payload com redundância de nomes (para cobrir variações da API)
      const payload = {
        nome: formData.nome.trim(),
        name: formData.nome.trim(),
        email: formData.email.trim(),
        username: formData.email.trim(),
        tipo_usuario: formData.tipo_usuario,
        tipoUsuario: formData.tipo_usuario,
        is_active: true,
      };
      if (formData.senha) {
        payload.senha = formData.senha;
        payload.password = formData.senha;
      }

      console.debug("Enviando payload (CriarUsuario):", payload);

      let response;
      if (isEditing) {
        response = await axios.put(
          `${API_URL}/usuarios/${encodeURIComponent(emailQuery)}`,
          payload,
          {
            headers: {
              Authorization: `Bearer ${getToken()}`,
              "Content-Type": "application/json",
            },
          }
        );
      } else {
        response = await axios.post(`${API_URL}/usuarios/`, payload, {
          headers: {
            Authorization: `Bearer ${getToken()}`,
            "Content-Type": "application/json",
          },
        });
      }

      // Se chegou aqui, status 2xx
      const respData = response.data || {};

      // procura por senha temporária em vários formatos possíveis retornados pelo backend
      const tempCandidates = [
        respData.temp_password,
        respData.tempPassword,
        respData.password,
        respData.senha_temp,
        respData.senha,
        respData.usuario?.temp_password,
        respData.usuario?.tempPassword,
        respData.usuario?.password,
        respData.user?.temp_password,
        respData.user?.password,
      ];
      const tempPassword = tempCandidates.find(Boolean);

      if (tempPassword && !isEditing) {
        // se for criação (não edição) e backend retornou senha temporária, copia e avisa
        try {
          if (navigator.clipboard && navigator.clipboard.writeText) {
            await navigator.clipboard.writeText(String(tempPassword));
            alert(`Usuário cadastrado com sucesso!\nSenha temporária copiada para a área de transferência:\n${tempPassword}\n\nEnvie essa senha ao usuário por canal seguro.`);
          } else {
            alert(`Usuário cadastrado com sucesso!\nSenha temporária: ${tempPassword}\n(Copie e encaminhe ao usuário por canal seguro)`);
          }
        } catch (err) {
          // caso clipboard falhe
          alert(`Usuário cadastrado com sucesso!\nSenha temporária: ${tempPassword}\n(Copie e encaminhe ao usuário por canal seguro)`);
        }
        console.info("Senha temporária retornada pelo backend (DEBUG):", tempPassword);
      } else {
        alert(isEditing ? "Usuário atualizado com sucesso!" : "Usuário cadastrado com sucesso!");
      }

      navigate("/usuarios");
    } catch (error) {
      console.error("Erro ao salvar usuário:", error);
      const resp = error.response?.data;
      if (resp) {
        setServerResponseDebug(resp);
        const newErrors = {};
        const apiErrors = resp.errors ?? resp;
        if (typeof apiErrors === "object") {
          Object.keys(apiErrors).forEach((k) => {
            const v = apiErrors[k];
            if (Array.isArray(v)) newErrors[k] = v.join(" ");
            else if (typeof v === "string") newErrors[k] = v;
            else if (typeof v === "object" && v !== null) {
              const first = Object.values(v)[0];
              if (Array.isArray(first)) newErrors[k] = first.join(" ");
              else newErrors[k] = String(first);
            } else newErrors[k] = String(v);
          });
        }
        // normalizações
        if (newErrors.password && !newErrors.senha) newErrors.senha = newErrors.password;
        if (Object.keys(newErrors).length > 0) setErrors(newErrors);

        if (error.response.status === 409) {
          setServerError("Email já cadastrado no sistema");
        } else if (error.response.status === 422) {
          setServerError(resp.detail || "Erros de validação no formulário");
        } else {
          setServerError(resp.detail || resp.message || `Erro ${error.response.status}`);
        }
      } else if (error.request) {
        setServerError("Sem resposta do servidor. Verifique a conexão.");
      } else {
        setServerError("Erro ao processar a requisição");
      }
    } finally {
      setIsLoading(false);
    }
  };

  const handleCancel = () => navigate("/usuarios");
  const handleVoltar = () => navigate("/usuarios");

  return (
    <div className="min-h-screen bg-gray-100 py-8 px-4">
      {isLoading && <LoadingSpinner message={isEditing ? "Carregando usuário..." : "Salvando usuário..."} />}

      <div className="max-w-md mx-auto bg-white rounded-lg shadow-lg overflow-hidden">
        <div className="bg-gray-800 p-4">
          <div className="flex justify-between items-center mb-2">
            <button onClick={handleVoltar} className="bg-gray-600 hover:bg-gray-700 text-white px-3 py-1 rounded-md transition-colors duration-200 flex items-center">Voltar</button>
            <div className="text-center flex-1">
              <h1 className="text-white text-xl font-bold">{isEditing ? "Editar Usuário" : "Cadastrar Usuário"}</h1>
            </div>
            <div className="w-20" />
          </div>
          <p className="text-blue-100 text-center">UTV LEGAL - Sistema de Gestão</p>
        </div>

        <div className="p-6">
          {/* Exibe a resposta bruta do servidor (útil para debug, cole aqui se o erro persistir) */}
          {serverResponseDebug && (
            <div className="mb-4 p-3 bg-yellow-50 border border-yellow-300 text-yellow-900 rounded">
              <strong>Resposta do servidor (debug):</strong>
              <pre className="mt-2 max-h-40 overflow-auto text-xs">{JSON.stringify(serverResponseDebug, null, 2)}</pre>
              <p className="text-xs mt-2">Se o erro continuar, cole esse JSON aqui para eu ajustar o payload.</p>
            </div>
          )}

          {serverError && (
            <div className="mb-4 bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative">{serverError}</div>
          )}

          <form onSubmit={handleSubmit} noValidate>
            <div className="mb-4">
              <label htmlFor="nome" className="block text-gray-700 font-medium mb-2">Nome</label>
              <input id="nome" name="nome" type="text" value={formData.nome} onChange={handleChange}
                className={`w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 ${errors.nome ? "border-red-500 focus:ring-red-500" : "border-gray-300 focus:ring-blue-500"}`}
                placeholder="Nome completo"
              />
              {errors.nome && <p className="text-red-500 text-sm mt-1">{errors.nome}</p>}
            </div>

            <div className="mb-4">
              <label htmlFor="email" className="block text-gray-700 font-medium mb-2">Email</label>
              <input id="email" name="email" type="email" value={formData.email} onChange={handleChange}
                className={`w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 ${errors.email ? "border-red-500 focus:ring-red-500" : "border-gray-300 focus:ring-blue-500"}`}
                placeholder="Digite o email do usuário"
              />
              {errors.email && <p className="text-red-500 text-sm mt-1">{errors.email}</p>}
            </div>

            <div className="mb-4">
              <label htmlFor="tipo_usuario" className="block text-gray-700 font-medium mb-2">Tipo de Usuário</label>
              <select id="tipo_usuario" name="tipo_usuario" value={formData.tipo_usuario} onChange={handleChange} className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                <option value="ADMIN">Administrador</option>
                <option value="FISCAL">Fiscal</option>
                <option value="USER">Usuário Comum</option>
              </select>
            </div>

            <div className="mb-4">
              <label htmlFor="senha" className="block text-gray-700 font-medium mb-2">Senha</label>
              <input id="senha" name="senha" type="password" value={formData.senha} onChange={handleChange}
                className={`w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 ${errors.senha ? "border-red-500 focus:ring-red-500" : "border-gray-300 focus:ring-blue-500"}`}
                placeholder={isEditing ? "Deixe em branco para manter a senha atual" : "Digite a senha"}
              />
              {errors.senha && <p className="text-red-500 text-sm mt-1">{errors.senha}</p>}
            </div>

            {!isEditing && (
              <div className="mb-6">
                <label htmlFor="confirmarSenha" className="block text-gray-700 font-medium mb-2">Confirmar Senha</label>
                <input id="confirmarSenha" name="confirmarSenha" type="password" value={formData.confirmarSenha} onChange={handleChange}
                  className={`w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 ${errors.confirmarSenha ? "border-red-500 focus:ring-red-500" : "border-gray-300 focus:ring-blue-500"}`}
                  placeholder="Confirme a senha"
                />
                {errors.confirmarSenha && <p className="text-red-500 text-sm mt-1">{errors.confirmarSenha}</p>}
              </div>
            )}

            <div className="flex space-x-4">
              <button type="button" onClick={handleCancel} className="flex-1 bg-gray-500 hover:bg-gray-600 text-white font-bold py-3 px-6 rounded-lg transition duration-200">Cancelar</button>
              <button type="submit" className="flex-1 bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-6 rounded-lg transition duration-200">{isEditing ? "Atualizar" : "Cadastrar"}</button>
            </div>
          </form>

          <div className="mt-8 text-center">
            <p className="text-sm text-gray-500">Sistema desenvolvido para gestão de veículos de tração</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CriarUsuario;
