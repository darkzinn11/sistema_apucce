// src/pages/MeusDados/index.jsx
import { useState, useEffect, useMemo } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import QRCode from "react-qr-code";

import Loading from "../../components/Loading";
import { API_URL } from "../../utils/apiUrl";
import { getCurrentUser, getToken } from "../../services/authService";

/* ========================= helpers ========================= */

// Se vier ArrayBuffer, converte; se já for string/base64, devolve como está
const arrayBufferToBase64 = (buffer) => {
  if (!buffer) return "";
  if (typeof buffer === "string") return buffer;
  let binary = "";
  const bytes = new Uint8Array(buffer);
  for (let i = 0; i < bytes.byteLength; i++) binary += String.fromCharCode(bytes[i]);
  return window.btoa(binary);
};

// Baixa/abre um PDF confiável usando Blob (evita aba cinza)
const downloadBase64Pdf = (base64, filename = "documento.pdf") => {
  const clean = arrayBufferToBase64(base64).replace(/\s+/g, "");
  try {
    const byteChars = atob(clean);
    const byteNumbers = new Array(byteChars.length);
    for (let i = 0; i < byteChars.length; i++) byteNumbers[i] = byteChars.charCodeAt(i);
    const byteArray = new Uint8Array(byteNumbers);
    const blob = new Blob([byteArray], { type: "application/pdf" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
  } catch {
    // fallback: tenta abrir em nova aba
    const dataUrl = `data:application/pdf;base64,${clean}`;
    window.open(dataUrl, "_blank");
  }
};

// baixa SVG do react-qr-code como PNG
const downloadQrPng = (svgId = "qr-svg", filename = "qrcode.png", scale = 4) => {
  const svg = document.getElementById(svgId);
  if (!svg) return;

  const svgData = new XMLSerializer().serializeToString(svg);
  const img = new Image();
  const svgBlob = new Blob([svgData], { type: "image/svg+xml;charset=utf-8" });
  const url = URL.createObjectURL(svgBlob);

  img.onload = function () {
    const canvas = document.createElement("canvas");
    const w = svg.viewBox.baseVal.width || 256;
    const h = svg.viewBox.baseVal.height || 256;
    canvas.width = w * scale;
    canvas.height = h * scale;
    const ctx = canvas.getContext("2d");
    ctx.fillStyle = "#ffffff";
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
    URL.revokeObjectURL(url);
    canvas.toBlob((blob) => {
      const dl = document.createElement("a");
      dl.href = URL.createObjectURL(blob);
      dl.download = filename;
      dl.click();
      URL.revokeObjectURL(dl.href);
    });
  };
  img.src = url;
};

/* ========================= normalizadores ========================= */

const normalizePiloto = (p) => {
  if (!p) return null;
  return {
    ...p,
    // pessoais
    nome_piloto: p.nome_piloto ?? p.nome ?? p.name ?? "",
    cpf_piloto: p.cpf_piloto ?? p.cpf ?? p.id_piloto ?? "",
    email_piloto: p.email_piloto ?? p.email ?? "",
    numero_telefone: p.numero_telefone ?? p.telefone ?? p.phone ?? "",
    data_nascimento: p.data_nascimento ?? p.nascimento ?? null,
    estado_civil: p.estado_civil ?? p.estadoCivil ?? null,
    tipo_sanguineo: p.tipo_sanguineo ?? p.tipoSanguineo ?? null,
    nome_contato_seguranca: p.nome_contato_seguranca ?? p.contatoEmergencia ?? "",
    numero_contato_seguranca: p.numero_contato_seguranca ?? p.foneEmergencia ?? "",
    nome_plano_saude: p.nome_plano_saude ?? p.planoSaude ?? "",
    id_piloto: p.id_piloto ?? "",

    // endereço (AGORA dentro de piloto)
    tipo_endereco: p.tipo_endereco ?? p.tipoEndereco ?? "RESIDENCIAL",
    cep: p.cep ?? "",
    logradouro: p.logradouro ?? "",
    numero: p.numero ?? "",
    complemento: p.complemento ?? "",
    bairro: p.bairro ?? "",
    cidade: p.cidade ?? "",
    uf: p.uf ?? "",
    pais: p.pais ?? "Brasil",

    // mídias
    foto_piloto: p.foto_piloto ?? null,
    foto_piloto_tipo: p.foto_piloto_tipo ?? "image/jpeg",
    foto_cnh: p.foto_cnh ?? null,
    foto_cnh_tipo: p.foto_cnh_tipo ?? null,
    termo_adesao: p.termo_adesao ?? null,
    termo_adesao_tipo: p.termo_adesao_tipo ?? "application/pdf",
  };
};

const normalizeCarro = (c) => {
  if (!c) return null;
  return {
    ...c,
    foto_frente: c.foto_frente ?? null,
    foto_tras: c.foto_tras ?? null,
    foto_esquerda: c.foto_esquerda ?? null,
    foto_direita: c.foto_direita ?? null,
    nota_fiscal: c.nota_fiscal ?? null,
  };
};

/* ========================= componentes ========================= */

const MeusDados = () => {
  const [piloto, setPiloto] = useState(null);
  const [carro, setCarro] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  const [carroAberto, setCarroAberto] = useState(false);
  const [enderecoAberto, setEnderecoAberto] = useState(false);
  const [termoAberto, setTermoAberto] = useState(false);

  const navigate = useNavigate();
  const authHeader = { headers: { Authorization: `Bearer ${getToken()}` } };

  const bloodType = (code) => {
    switch (Number(code)) {
      case 1: return "A positivo";
      case 2: return "A negativo";
      case 3: return "B positivo";
      case 4: return "B negativo";
      case 5: return "AB positivo";
      case 6: return "AB negativo";
      case 7: return "O positivo";
      case 8: return "O negativo";
      default: return "Tipo sanguíneo desconhecido";
    }
  };

  const estadoCivil = (code) => {
    switch (Number(code)) {
      case 1: return "Solteiro";
      case 2: return "Casado";
      case 3: return "Viúvo";
      case 4: return "Outros";
      default: return "Estado civil desconhecido";
    }
  };

  const tipoEndereco = (tipo) => {
    switch (tipo) {
      case "RESIDENCIAL": return "Residencial";
      case "COMERCIAL": return "Comercial";
      default: return tipo || "—";
    }
  };

  const renderImagemCarro = (imagemBase64, alt, className = "w-full h-48 object-cover rounded") => {
    if (!imagemBase64) {
      return (
        <div className="h-48 bg-gray-200 rounded flex items-center justify-center">
          <span className="text-gray-500">Imagem não disponível</span>
        </div>
      );
    }
    return (
      <img
        src={`data:image/jpeg;base64,${arrayBufferToBase64(imagemBase64)}`}
        alt={alt}
        className={className}
        onError={(e) => {
          e.target.onerror = null;
          e.target.src = "/placeholder-car.jpg";
        }}
      />
    );
  };

  const renderFotoPiloto = (p) => {
    if (!p?.foto_piloto) {
      return (
        <div className="w-32 h-32 rounded-full bg-gray-200 flex items-center justify-center">
          <span className="text-gray-500">Sem foto</span>
        </div>
      );
    }
    const b64 = arrayBufferToBase64(p.foto_piloto);
    return (
      <img
        src={`data:${p.foto_piloto_tipo || "image/jpeg"};base64,${b64}`}
        alt={`Foto de ${p.nome_piloto || ""}`}
        className="w-32 h-32 rounded-full object-cover border-4 border-gray-200"
        onError={(e) => {
          e.target.onerror = null;
          e.target.src = "/placeholder-user.jpg";
        }}
      />
    );
  };

  const renderCNH = (cnhBase64, fileType, className = "bg-gray-100 p-4 rounded-lg") => {
    if (!cnhBase64) {
      return (
        <div className={className}>
          <div className="flex items-center justify-center">
            <span className="text-gray-500">CNH não disponível</span>
          </div>
        </div>
      );
    }
    if ((fileType || "").startsWith("application/pdf")) {
      return (
        <div className={className}>
          <div className="flex items-center justify-between">
            <span className="text-gray-700">CNH (PDF)</span>
            <button
              onClick={() => downloadBase64Pdf(cnhBase64, "cnh.pdf")}
              className="bg-blue-600 hover:bg-blue-700 text-white px-3 py-1 rounded text-sm"
            >
              Baixar PDF
            </button>
          </div>
        </div>
      );
    }
    return (
      <div className={className}>
        <label className="block text-sm font-medium text-gray-500 mb-2">CNH (Imagem)</label>
        <img
          src={`data:${fileType || "image/jpeg"};base64,${arrayBufferToBase64(cnhBase64)}`}
          alt="CNH do piloto"
          className="w-full h-auto rounded-lg border border-gray-300"
          onError={(e) => {
            e.target.onerror = null;
            e.target.src = "/placeholder-doc.jpg";
          }}
        />
      </div>
    );
  };

  const renderTermoAdesao = (termoBase64, className = "bg-gray-100 p-4 rounded-lg") => {
    if (!termoBase64) {
      return (
        <div className={className}>
          <div className="flex items-center justify-center">
            <span className="text-gray-500">Termo de adesão não disponível</span>
          </div>
        </div>
      );
    }
    return (
      <div className={className}>
        <div className="flex items-center justify-between">
          <span className="text-gray-700">Termo de Adesão (PDF)</span>
          <button
            onClick={() => downloadBase64Pdf(termoBase64, "termo_adesao.pdf")}
            className="bg-blue-600 hover:bg-blue-700 text-white px-3 py-1 rounded text-sm"
          >
            Baixar PDF
          </button>
        </div>
      </div>
    );
  };

  /* ========================= efeito ========================= */

  useEffect(() => {
    const fetchData = async () => {
      try {
        const user = getCurrentUser();
        const userEmail = user?.email;
        if (!userEmail) throw new Error("E-mail do usuário não encontrado.");

        // 1) Piloto (já vem com endereço embutido)
        const rPiloto = await axios.get(
          `${API_URL}/pilotos/email/${encodeURIComponent(userEmail)}`,
          authHeader
        );
        const pilotoData = normalizePiloto(rPiloto.data);
        setPiloto(pilotoData);

        // 2) Carro
        try {
          const rCarro = await axios.get(
            `${API_URL}/carros/${encodeURIComponent(pilotoData.cpf_piloto)}`,
            authHeader
          );
          setCarro(normalizeCarro(rCarro.data));
        } catch {
          setCarro(null);
        }
      } catch (err) {
        console.error(err);
        alert("Não foi possível carregar seus dados.");
      } finally {
        setIsLoading(false);
      }
    };
    fetchData();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  /* ========================= QR CODE ========================= */

  // dado que vai codificado no QR (leve e útil pra fiscalização)
  const qrPayload = useMemo(() => {
    if (!piloto) return "";
    // pode ser só o id_piloto, mas mando também o cpf (fica robusto)
    return JSON.stringify({
      id: piloto.id_piloto || "",
      cpf: piloto.cpf_piloto || "",
      nome: piloto.nome_piloto || "",
    });
  }, [piloto]);

  /* ========================= UI ========================= */

  if (isLoading) return <Loading message="Carregando seus dados..." />;

  if (!piloto) {
    return (
      <div className="min-h-screen bg-gray-100 flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-xl font-semibold mb-4">Dados não encontrados</h2>
          <p>Seus dados de piloto não foram encontrados.</p>
          <button
            onClick={() => navigate("/home")}
            className="mt-4 bg-blue-600 text-white px-4 py-2 rounded"
          >
            Voltar
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-100 p-4">
      <div className="max-w-4xl mx-auto bg-white rounded-lg shadow-md overflow-hidden">
        {/* Cabeçalho */}
        <div className="bg-gray-800 p-6 text-white">
          <div className="flex justify-between items-start">
            <div>
              <h1 className="text-2xl font-bold">UTV LEGAL</h1>
              <p className="text-blue-100">Meus Dados</p>
            </div>
            <button
              onClick={() => navigate("/home")}
              className="bg-gray-600 hover:bg-gray-700 text-white px-4 py-2 rounded-md"
            >
              Voltar
            </button>
          </div>
        </div>

        {/* Conteúdo */}
        <div className="p-6 space-y-6">
          {/* Foto */}
          <div className="flex justify-center">{renderFotoPiloto(piloto)}</div>

          {/* CNH */}
          <div className="pt-4 border-t border-gray-200">
            <h4 className="text-sm font-medium text-gray-500 mb-2">
              Carteira de Motorista (CNH)
            </h4>
            {renderCNH(piloto.foto_cnh, piloto.foto_cnh_tipo)}
          </div>

          {/* Info Pessoais */}
          <div className="space-y-4">
            <h3 className="text-xl font-semibold text-gray-800 border-b pb-2">
              Informações Pessoais
            </h3>

            <div>
              <label className="block text-sm font-medium text-gray-500">
                Nome Completo
              </label>
              <p className="mt-1 text-gray-900 text-lg font-medium">
                {piloto.nome_piloto}
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-500">
                  CPF
                </label>
                <p className="mt-1 text-gray-900">{piloto.cpf_piloto}</p>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-500">
                  Data de Nascimento
                </label>
                <p className="mt-1 text-gray-900">
                  {piloto.data_nascimento
                    ? new Date(piloto.data_nascimento).toLocaleDateString("pt-BR")
                    : "Não informada"}
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-500">
                  Tipo Sanguíneo
                </label>
                <p className="mt-1 text-gray-900">
                  {bloodType(piloto.tipo_sanguineo)}
                </p>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-500">
                  Estado Civil
                </label>
                <p className="mt-1 text-gray-900">
                  {estadoCivil(piloto.estado_civil)}
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-500">
                  E-mail
                </label>
                <p className="mt-1 text-gray-900">{piloto.email_piloto}</p>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-500">
                  Celular
                </label>
                <p className="mt-1 text-gray-900">
                  {piloto.numero_telefone}
                </p>
              </div>
            </div>
          </div>

          {/* Contato de Emergência */}
          <div className="space-y-4">
            <h3 className="text-xl font-semibold text-gray-800 border-b pb-2">
              Contato de Emergência
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-500">
                  Nome do Contato
                </label>
                <p className="mt-1 text-gray-900">
                  {piloto.nome_contato_seguranca || "Não informado"}
                </p>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-500">
                  Telefone do Contato
                </label>
                <p className="mt-1 text-gray-900">
                  {piloto.numero_contato_seguranca || "Não informado"}
                </p>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-500">
                Plano de Saúde
              </label>
              <p className="mt-1 text-gray-900">
                {piloto.nome_plano_saude || "Não informado"}
              </p>
            </div>
          </div>

          {/* Endereço (agora do próprio piloto) */}
          <div className="space-y-4">
            <button
              onClick={() => setEnderecoAberto(!enderecoAberto)}
              className="flex justify-between items-center w-full text-left py-2 font-medium text-gray-800 hover:text-blue-600 focus:outline-none"
            >
              <h3 className="text-xl font-semibold">Endereço</h3>
              <svg
                className={`w-5 h-5 transition-transform duration-200 ${
                  enderecoAberto ? "transform rotate-180" : ""
                }`}
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
              </svg>
            </button>

            {enderecoAberto && (
              <div className="mt-4 space-y-4 pl-2 border-l-2 border-blue-200 ml-1">
                <div>
                  <label className="block text-sm font-medium text-gray-500">
                    Tipo de Endereço
                  </label>
                  <p className="mt-1 text-gray-900">{tipoEndereco(piloto.tipo_endereco)}</p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-500">CEP</label>
                    <p className="mt-1 text-gray-900">{piloto.cep || "Não informado"}</p>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-500">Número</label>
                    <p className="mt-1 text-gray-900">{piloto.numero || "S/N"}</p>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-500">Logradouro</label>
                  <p className="mt-1 text-gray-900">{piloto.logradouro || "Não informado"}</p>
                </div>

                {piloto.complemento ? (
                  <div>
                    <label className="block text-sm font-medium text-gray-500">Complemento</label>
                    <p className="mt-1 text-gray-900">{piloto.complemento}</p>
                  </div>
                ) : null}

                <div>
                  <label className="block text-sm font-medium text-gray-500">Bairro</label>
                  <p className="mt-1 text-gray-900">{piloto.bairro || "Não informado"}</p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-500">Cidade</label>
                    <p className="mt-1 text-gray-900">{piloto.cidade || "Não informada"}</p>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-500">UF</label>
                    <p className="mt-1 text-gray-900">{piloto.uf || "Não informado"}</p>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-500">País</label>
                  <p className="mt-1 text-gray-900">{piloto.pais || "Não informado"}</p>
                </div>
              </div>
            )}
          </div>

          {/* Termo de adesão */}
          {piloto.termo_adesao && (
            <div className="space-y-4">
              <button
                onClick={() => setTermoAberto(!termoAberto)}
                className="flex justify-between items-center w-full text-left py-2 font-medium text-gray-800 hover:text-blue-600 focus:outline-none"
              >
                <h3 className="text-xl font-semibold">Termo de Adesão</h3>
                <svg
                  className={`w-5 h-5 transition-transform duration-200 ${
                    termoAberto ? "transform rotate-180" : ""
                  }`}
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                </svg>
              </button>

              {termoAberto && (
                <div className="mt-4 space-y-4 pl-2 border-l-2 border-blue-200 ml-1">
                  {renderTermoAdesao(piloto.termo_adesao)}
                </div>
              )}
            </div>
          )}

          {/* Veículo */}
          {carro ? (
            <div className="space-y-4">
              <button
                onClick={() => setCarroAberto(!carroAberto)}
                className="flex justify-between items-center w-full text-left py-2 font-medium text-gray-800 hover:text-blue-600 focus:outline-none"
              >
                <h3 className="text-xl font-semibold">Veículo</h3>
                <svg
                  className={`w-5 h-5 transition-transform duration-200 ${
                    carroAberto ? "transform rotate-180" : ""
                  }`}
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                </svg>
              </button>

              {carroAberto && (
                <div className="mt-4 space-y-4 pl-2 border-l-2 border-blue-200 ml-1">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-500 mb-2">
                        Frente do Veículo
                      </label>
                      {renderImagemCarro(carro.foto_frente, "Frente do veículo")}
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-500 mb-2">
                        Traseira do Veículo
                      </label>
                      {renderImagemCarro(carro.foto_tras, "Traseira do veículo")}
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-500 mb-2">
                        Lado Esquerdo
                      </label>
                      {renderImagemCarro(carro.foto_esquerda, "Lado esquerdo do veículo")}
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-500 mb-2">
                        Lado Direito
                      </label>
                      {renderImagemCarro(carro.foto_direita, "Lado direito do veículo")}
                    </div>
                  </div>

                  {carro.nota_fiscal && (
                    <div>
                      <label className="block text-sm font-medium text-gray-500 mb-2">
                        Nota Fiscal
                      </label>
                      <div className="bg-gray-100 p-4 rounded-lg">
                        <div className="flex items-center justify-between">
                          <span className="text-gray-700">Documento disponível</span>
                          <button
                            onClick={() => downloadBase64Pdf(carro.nota_fiscal, "nota_fiscal.pdf")}
                            className="bg-blue-600 hover:bg-blue-700 text-white px-3 py-1 rounded text-sm"
                          >
                            Baixar PDF
                          </button>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>
          ) : (
            <div className="bg-yellow-100 border border-yellow-400 text-yellow-700 px-4 py-3 rounded">
              Nenhum veículo cadastrado
            </div>
          )}

          {/* QR CODE (final do perfil) */}
          <div className="pt-6 border-t border-gray-200">
            <h3 className="text-xl font-semibold text-gray-800 mb-3">Identificação do Piloto</h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-center">
              <div>
                <p className="text-sm text-gray-500">ID do Piloto (gerado pelo sistema)</p>
                <p className="mt-1 text-gray-900 break-all">
                  {piloto.id_piloto || "—"}
                </p>
              </div>

              <div className="flex flex-col items-center gap-3">
                <div className="bg-white p-3 rounded-lg border" style={{ width: 192 }}>
                  <QRCode
                    id="qr-svg"
                    value={qrPayload}
                    size={180}
                    level="M"
                    includeMargin
                  />
                </div>
                <div className="flex gap-2">
                  <button
                    onClick={() => downloadQrPng("qr-svg", "qrcode_piloto.png")}
                    className="bg-blue-600 hover:bg-blue-700 text-white px-3 py-1 rounded text-sm"
                  >
                    Baixar QR Code (PNG)
                  </button>
                </div>
                <p className="text-xs text-gray-500 text-center">
                  O QR codifica: {"{ id, cpf, nome }"} do piloto. A fiscalização pode ler para identificar.
                </p>
              </div>
            </div>
          </div>
          {/* fim QR */}
        </div>
      </div>
    </div>
  );
};

export default MeusDados;