// src/pages/MudarSenha/index.jsx
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";

import { API_URL } from "../../utils/apiUrl.js";          // <= ajustado
import { getToken } from "../../services/authService.js"; // <= ajustado

export default function MudarSenha() {
  const navigate = useNavigate();
  const [senhaAtual, setSenhaAtual] = useState("");
  const [novaSenha, setNovaSenha] = useState("");
  const [confirmar, setConfirmar] = useState("");
  const [msg, setMsg] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setMsg("");

    if (!novaSenha || novaSenha.length < 8) {
      setMsg("A nova senha deve ter pelo menos 8 caracteres.");
      return;
    }
    if (novaSenha !== confirmar) {
      setMsg("A confirmação não confere.");
      return;
    }

    setLoading(true);
    try {
      await axios.post(
        `${API_URL}/auth/change-password`,
        { current_password: senhaAtual, new_password: novaSenha },
        { headers: { Authorization: `Bearer ${getToken()}` } }
      );

      setMsg("Senha alterada com sucesso! Redirecionando…");
      setTimeout(() => navigate("/home", { replace: true }), 600);
    } catch (err) {
      const detail =
        err.response?.data?.detail ||
        err.response?.data?.message ||
        "Não foi possível alterar a senha.";
      setMsg(detail);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-100 p-4">
      <div className="w-full max-w-md bg-white rounded-xl shadow p-6">
        <h1 className="text-xl font-semibold text-gray-800 mb-1">
          Defina sua nova senha
        </h1>
        <p className="text-sm text-gray-500 mb-4">
          Por segurança, é necessário trocar a senha padrão no primeiro acesso.
        </p>

        {msg && (
          <div className="mb-3 text-sm p-3 rounded bg-blue-50 text-blue-800">
            {msg}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-3">
          <div>
            <label className="block text-sm text-gray-700">Senha atual</label>
            <input
              type="password"
              value={senhaAtual}
              onChange={(e) => setSenhaAtual(e.target.value)}
              className="mt-1 w-full border rounded px-3 py-2"
              placeholder="Senha padrão"
            />
          </div>

          <div>
            <label className="block text-sm text-gray-700">Nova senha</label>
            <input
              type="password"
              value={novaSenha}
              onChange={(e) => setNovaSenha(e.target.value)}
              className="mt-1 w-full border rounded px-3 py-2"
              placeholder="Mínimo 8 caracteres"
            />
          </div>

          <div>
            <label className="block text-sm text-gray-700">
              Confirmar nova senha
            </label>
            <input
              type="password"
              value={confirmar}
              onChange={(e) => setConfirmar(e.target.value)}
              className="mt-1 w-full border rounded px-3 py-2"
              placeholder="Repita a nova senha"
            />
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-blue-600 hover:bg-blue-700 text-white font-medium py-2.5 rounded disabled:opacity-70"
          >
            {loading ? "Salvando..." : "Alterar senha"}
          </button>
        </form>
      </div>
    </div>
  );
}
